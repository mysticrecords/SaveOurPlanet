package SaveOurPlanet;

public class PropertyArea extends Area {

	// area names
	private final String FINLAND = "Finland";
	private final String SWEDEN = "Sweden";
	private final String UK = "UK";
	private final String GERMANY = "Germany";
	private final String RUSSIA = "Russia";
	private final String JAPAN = "Japan";
	private final String INDIA = "India";
	private final String CHINA = "China";
	private final String CANADA = "Canada";
	private final String USA = "USA";

	// field names
	private final String NORTHERN_EUROPE = "Northern Europe";
	private final String CENTRAL_EUROPE = "Central Europe";
	private final String ASIA = "Asia";
	private final String NORTH_AMERICA = "North America";

	// field index
	private final int FIELD_1 = 1;
	private final int FIELD_2 = 2;
	private final int FIELD_3 = 3;
	private final int FIELD_4 = 4;

	// area index
	private final int AREA_TWO = 1;
	private final int AREA_THREE = 2;
	private final int AREA_FOUR = 3;
	private final int AREA_FIVE = 4;
	private final int AREA_SIX = 5;

	// area index
	private final int AREA_EIGHT = 7;
	private final int AREA_NINE = 8;
	private final int AREA_TEN = 9;
	private final int AREA_ELEVEN = 10;
	private final int AREA_TWELVE = 11;

	// carbon footprint related finals (purchase cost, pollute cost & build cost)
	private final int PURCHASE_COST = 100;
	private final int POLLUTE_COST = 30;
	private final int BUILD_COST = 100;

	// development count parameters
	private final int MAX_DEVELOPMENT_COUNT = 4;
	private final int DEFAULT_DEVELOPMENT_COUNT = 0;

	// default owner value
	private final int DEFAULT_OWNER_VALUE = 0;

	// risk levels used in equation for purchase cost, pollute cost & build cost)
	private final int RISK_LEVEL_ONE = 1;
	private final int RISK_LEVEL_TWO = 2;
	private final int RISK_LEVEL_THREE = 3;

	private int developmentCount;
	private int areaCost;
	private int polluteCost;
	private int isOwned;
	private int buildPropertyCost;
	private Field field;

	public PropertyArea() {

	}

	public PropertyArea(int areaPosition) {
		if (areaPosition == 1) {

			field = new Field(NORTHERN_EUROPE, FIELD_1, RISK_LEVEL_ONE);

			super.setName(FINLAND);
			super.setIndex(AREA_TWO);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 2) {

			field = new Field(NORTHERN_EUROPE, FIELD_1, RISK_LEVEL_ONE);

			super.setName(SWEDEN);
			super.setIndex(AREA_THREE);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 3) {

			field = new Field(CENTRAL_EUROPE, FIELD_2, RISK_LEVEL_TWO);

			super.setName(UK);
			super.setIndex(AREA_FOUR);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 4) {

			field = new Field(CENTRAL_EUROPE, FIELD_2, RISK_LEVEL_TWO);

			super.setName(GERMANY);
			super.setIndex(AREA_FIVE);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 5) {

			field = new Field(CENTRAL_EUROPE, FIELD_2, RISK_LEVEL_TWO);

			super.setName(RUSSIA);
			super.setIndex(AREA_SIX);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 7) {

			field = new Field(ASIA, FIELD_3, RISK_LEVEL_TWO);

			super.setName(JAPAN);
			super.setIndex(AREA_EIGHT);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 8) {

			field = new Field(ASIA, FIELD_3, RISK_LEVEL_TWO);

			super.setName(INDIA);
			super.setIndex(AREA_NINE);
			this.field.setRiskLevel(RISK_LEVEL_TWO);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			field.setFieldIndex(FIELD_3);
			field.setFieldName(ASIA);
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 9) {

			field = new Field(ASIA, FIELD_3, RISK_LEVEL_TWO);

			super.setName(CHINA);
			super.setIndex(AREA_TEN);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else if (areaPosition == 10) {

			field = new Field(NORTH_AMERICA, FIELD_4, RISK_LEVEL_THREE);

			super.setName(CANADA);
			super.setIndex(AREA_ELEVEN);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());

		} else {

			field = new Field(NORTH_AMERICA, FIELD_4, RISK_LEVEL_THREE);

			super.setName(USA);
			super.setIndex(AREA_TWELVE);
			this.areaCost = PURCHASE_COST * field.getRiskLevel();
			this.setIsOwned(DEFAULT_OWNER_VALUE);
			this.setDevelopmentCount(DEFAULT_DEVELOPMENT_COUNT);
			this.setPolluteCost(POLLUTE_COST * field.getRiskLevel());
			this.setBuildPropertyCost(BUILD_COST * field.getRiskLevel());
		}
	}

	
	
	/**
	 * @return the field
	 */
	public Field getField() {
		return field;
	}

	/**
	 * @param field the field to set
	 */
	public void setField(Field field) {
		this.field = field;
	}

	/**
	 * @return the buildPropertyCost
	 */

	public int getBuildPropertyCost() {
		return buildPropertyCost;
	}

	/**
	 * @param buildPropertyCost the buildPropertyCost to set
	 */
	public void setBuildPropertyCost(int buildPropertyCost) {
		this.buildPropertyCost = buildPropertyCost;
	}

	/**
	 * @return the areaCost
	 */
	public int getAreaCost() {
		return areaCost;
	}

	/**
	 * @return the polluteCost
	 */
	public int getPolluteCost() {
		return polluteCost;
	}

	/**
	 * @param polluteCost the polluteCost to set
	 */
	public void setPolluteCost(int polluteCost) {
		this.polluteCost = polluteCost;
	}

	/**
	 * @return the developmentCount
	 */
	public int getDevelopmentCount() {
		return developmentCount;
	}

	/**
	 * @param developmentCount the developmentCount to set
	 */
	public void setDevelopmentCount(int developmentCount) {
		this.developmentCount = developmentCount;
	}

	/**
	 * @return the isOwned
	 */

	public int getIsOwned() {
		return isOwned;
	}

	/**
	 * @param isOwned the isOwned to set
	 */

	public void setIsOwned(int isOwned) {
		this.isOwned = isOwned;
	}
	
	/**
	 * @return the mAX_DEVELOPMENT_COUNT
	 */
	public int getMAX_DEVELOPMENT_COUNT() {
		return MAX_DEVELOPMENT_COUNT;
	}
	
	/**
	 * @return the pOLLUTE_COST
	 */
	public int getPOLLUTE_COST() {
		return this.POLLUTE_COST;
	}


}
