package SaveOurPlanet;

import java.util.ArrayList;

public interface IPrintBanners {
	
	public void printStartGameBanner();
	
	public void getAreaDetails(ArrayList<Area> area, int areaPosition);
	
	public void printEndGameBanner();
	
	public void printGameStatsBanner();
	
	public void printWinnerBanner();
	
	public void printGameResultsBanner();
	
	public void printDivider();
	
	public void printLoserBanner();

}
