package SaveOurPlanet;

import java.util.Scanner;

public class SaveOurPlanet {

	// static Scanner that can be used across all methods
	public static Scanner input = new Scanner(System.in);

	// Save Our Planet Main Game
	public static void main(String[] args) {

		// initialize game
		new Game();

		// closing static scanner
		input.close();

	} // end Save Our Planet Game

}
