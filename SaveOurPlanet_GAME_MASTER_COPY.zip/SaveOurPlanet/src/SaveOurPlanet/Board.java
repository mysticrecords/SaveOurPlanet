/**
 * 
 */
package SaveOurPlanet;

import java.util.ArrayList;

/**
 * @author mattwalsh
 *
 */
public class Board {

	private final int LIMIT = 12;

	private ArrayList<Area> areas = new ArrayList<Area>();

	private Area area;
	private PropertyArea propertyArea;
	private GoGreenArea goGreenArea;
	private TakeABreakArea takeABreakArea;

	public Board() {

		for (int i = 0; i < LIMIT; i++) {

			if (i == 0) {
				areas.add(goGreenArea = new GoGreenArea(i));
			} else if (i == 1) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 2) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 3) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 4) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 5) {
				areas.add(area = new PropertyArea(i));
			} else if (i == 6) {
				areas.add(takeABreakArea = new TakeABreakArea(i));
			} else if (i == 7) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 8) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 9) {
				areas.add(propertyArea = new PropertyArea(i));
			} else if (i == 10) {
				areas.add(propertyArea = new PropertyArea(i));
			} else {
				areas.add(propertyArea = new PropertyArea(i));
			}
		}

	}

	/**
	 * @return the area
	 */
	public Area getArea() {
		return area;
	}

	/**
	 * @param area
	 *            the area to set
	 */
	public void setArea(Area area) {
		this.area = area;
	}

	/**
	 * @return the areas
	 */
	public ArrayList<Area> getAreas() {
		return areas;
	}

	/**
	 * @param areas
	 *            the areas to set
	 */
	public void setAreas(ArrayList<Area> areas) {
		this.areas = areas;
	}

}
