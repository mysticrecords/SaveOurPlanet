package SaveOurPlanet;

public abstract class Area {

	private String name;
	private int index;

	public Area() {

	}

	/**
	 * @param name
	 * @param index
	 */
	public Area(String name, int index) {
		super();
		this.name = name;
		this.index = index;

	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(int index) {
		this.index = index;
	}

	/**
	 * @return the index
	 */
	public int getIndex() {
		return index;
	}

}
