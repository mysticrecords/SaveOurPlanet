package SaveOurPlanet;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Random;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class Game implements IDice, ISoundEffects, IPrintBanners {

	// parameter values
	private final int MIN_PLAYERS = 2;
	private final int MAX_PLAYERS = 4;

	private final int MIN_TOKEN = 1;
	private final int MAX_TOKEN = 8;

	private final int CARBON_FOOTPRINT_MAX_LIMIT = 9000;
	private final int CARBON_FOOTPRINT_WIN_LIMIT = 0;

	private final int END_GAME = 2;

	private int roundCount = 0;

	private ArrayList<GamePlayer> players = new ArrayList<GamePlayer>();

	private Board board;
	private GamePlayer player;

	public Game() {
		this.board = new Board();
		this.player = new GamePlayer();
		enterInfo(getPlayers());
		makeMove(getPlayers(), getBoard().getAreas());

	}

	/**
	 * @return the board
	 */
	public Board getBoard() {
		return board;
	}

	/**
	 * @return the player
	 */
	public GamePlayer getPlayer() {
		return player;
	}

	/**
	 * @return the players
	 */
	public ArrayList<GamePlayer> getPlayers() {
		return players;
	}

	/************************************************************************************************************************/
	/*
	 * debugging methods ONLY
	 */

	// print all board areas (USED FOR DEBUGGING PURPOSES ONLY)
	public void printAreas(ArrayList<Area> areas) {

		// ArrayList<PropertyArea> propertyTemp = new ArrayList<PropertyArea>();

		System.out.println(String.format("%-22s%-8s", "Area", "Index"));
		printDivider();

		for (int i = 0; i < areas.size(); i++) {

			if (areas.get(i).getIndex() == 0) {

				GoGreenArea goGreenTemp = (GoGreenArea) areas.get(i);
				System.out.println(String.format("%-22s%-8d\n", goGreenTemp.getName(), goGreenTemp.getIndex()));

			} else if (areas.get(i).getIndex() == 6) {

				TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(i);
				System.out.println(String.format("%-22s%-8d\n", takeABreakTemp.getName(), takeABreakTemp.getIndex()));
			}

			else {
				PropertyArea propertyTemp = (PropertyArea) areas.get(i);
				System.out.println(String.format("%-22s%-8d\n", propertyTemp.getName(), propertyTemp.getIndex()));
			}
		}

		printDivider();

	} // end printAreas method

	/************************************************************************************************************************/
	/*
	 * game methods and use cases
	 */

	// add players to the players arraylist
	public void setPlayers(ArrayList<GamePlayer> players) {

		this.players = players;

	} // end setPlayers method

	// compare players carbon footprint and adjust results board accordingly (least
	// to most)
	public static Comparator<GamePlayer> playerComparator = new Comparator<GamePlayer>() {

		public int compare(GamePlayer o1, GamePlayer o2) {

			Integer pl1 = Integer.valueOf(o1.getCarbonFootprint());
			Integer pl2 = Integer.valueOf(o2.getCarbonFootprint());

			return pl1 - pl2;

		}
	}; // end compare method

	// print game player leaderboard

	// UC4 displayInfo (player details) use case (this will appear multiple times)
	public void printPlayerDetails(ArrayList<GamePlayer> player) {

		ArrayList<GamePlayer> leaderboard = new ArrayList<GamePlayer>(player);

		System.out.println(String.format("                  %-10s%-20s%-20s%-20s%-20s", "Ranking", "Player",
				"Carbon Footprint", "Player Token", "Player Position"));

		Collections.sort(leaderboard, Game.playerComparator);

		for (GamePlayer p : leaderboard) {

			System.out.print(String.format("                  %-10d%-20s%-20d", leaderboard.indexOf(p) + 1,
					p.getPlayerName(), p.getCarbonFootprint()));
			System.out.printf(String.format("%-20s", p.getToken().getTokenName(), leaderboard));
			System.out.print(String.format("%-20d", p.getPlayerPosition()));
			System.out.println();
		}

	} // end printPlayerDetails method

	// UC1 enter info use case
	public void enterInfo(ArrayList<GamePlayer> players) {

		// print statement for debugging
		// printAreas(board.getAreas());

		// empty constructor so Player methods are accessible
		int numPlayers = 0;

		PlayerToken token = new PlayerToken();

		// flag to break out of loops
		boolean isException = false;

		printStartGameBanner();
		welcomeSound();

		printDivider();
		System.out.println("");
		System.out.println("                                             Welcome to Save Our Planet!");
		System.out.println("");
		System.out.println("                                                  Lets get started!");
		System.out.println("");
		printDivider();
		System.out.println("");

		// enter number of players for the game
		do {

			// catch invalid input (only int is accepted)
			try {

				do {

					System.out.println("How many players would you like to play? \n(choose an option between 2 - 4)");
					numPlayers = SaveOurPlanet.input.nextInt();
					SaveOurPlanet.input.nextLine();

					isException = false;

					// player input validation
					// only between MIN & MAX static finals (inclusive) are valid
					// continue in this loop until a valid input is entered
					while (numPlayers < MIN_PLAYERS || numPlayers > MAX_PLAYERS) {

						// UC2 display error message use case
						System.out.println("Invalid number.  Must be in the range 2 - 4");
						System.out.println("Please try again.");
						System.out.println("");
						System.out.println("How many players would you like to play?");
						System.out.println("(choose an option between 2 - 4)");

						numPlayers = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();

					} // end while

				} while (numPlayers < MIN_PLAYERS || numPlayers > MAX_PLAYERS); // end inner
																				// do while

			} catch (InputMismatchException mismatch) {

				isException = true;

				// UC2 display error message use case
				System.out.println("");
				System.out.println("Invalid Input.");
				System.out.println("Please enter a number between " + MIN_PLAYERS + " - " + MAX_PLAYERS + " inclusive");
				System.out.println("");

				SaveOurPlanet.input.nextLine();

			} // end mismatch try

		} while (isException == true); // end out do while

		/*******************************************************************************************/

		// once a valid number of players has been entered
		// enter the player name. the player name must be unique
		System.out.println("");
		System.out.println("Thanks, we have " + numPlayers + " players \n");
		printDivider();

		String playerName = "";
		int playerTurn = 1;
		boolean exists = false;

		// create a player
		do {

			try {

				String turn = "";

				switch (playerTurn) {
				case 1:
					turn = "One";
					break;
				case 2:
					turn = "Two";
					break;
				case 3:
					turn = "Three";
					break;
				case 4:
					turn = "Four";
					break;

				}

				System.out.println("Please enter Player " + turn + "'s Name:");
				playerName = SaveOurPlanet.input.next();

				// check to see if player name has already been taken
				do {
					for (GamePlayer p : players) {

						// check ArrayList to see does the player name exist
						// if true display error message and prompt user to renter their name
						if (playerName.equalsIgnoreCase(p.getPlayerName())) {

							exists = true;

							// UC2 display error message use case
							System.out.println("");
							System.out.println("Sorry '" + playerName + "' is already in use.");
							System.out.println("Please enter a different name:");
							System.out.println();

							System.out.println("Please enter the Players Name:");
							playerName = SaveOurPlanet.input.next();

						}
						// if player name does not exist, continue
						else {
							exists = false;
						}

					} // end for loop
				} while (players.size() > 0 && exists); // end inner do while

			} catch (Exception enterPlayerName) {
				// UC2 display error message use case
				System.out.println();
				System.out.println("Enter Player Details Exception");
				System.out.println();
			} // end try catch

			/*******************************************************************************************/

			int tokenID = 0;

			// boolean tokenException = false;

			do {

				try {

					// player selects their token
					System.out.println("");
					System.out.println("Please select your token:\n");

					for (PlayerToken t : player.getTokens()) {
						System.out
								.print(String.format("%d. %-11s", player.getTokens().indexOf(t) + 1, t.getTokenName()));
					}

					System.out.println("");
					tokenID = SaveOurPlanet.input.nextInt();

					do {

						isException = false;

						while (tokenID < MIN_TOKEN || tokenID > MAX_TOKEN) {

							// UC2 display error message use case
							System.out.println("");
							System.out
									.println("Invalid number.  Must be in the range " + MIN_TOKEN + " - " + MAX_TOKEN);
							System.out.println("Please try again.");
							System.out.println("");
							System.out.println("Please select your token:");
							System.out.println("(choose an option between " + MIN_TOKEN + " - " + MAX_TOKEN + ")");

							for (PlayerToken t : player.getTokens()) {
								System.out.print(String.format("%d. %-11s", player.getTokens().indexOf(t) + 1,
										t.getTokenName()));
							}

							System.out.println("");
							tokenID = SaveOurPlanet.input.nextInt();

						} // end while

						String tokenName = selectToken(tokenID - 1);

						do {
							for (GamePlayer p : players) {
								if (p.getToken().getTokenName().equalsIgnoreCase(tokenName)) {

									exists = true;

									System.out.println("");
									System.out.println("Sorry '" + tokenName + "' is already in use.");
									System.out.println("Please choose a different token:");
									System.out.println("");

									System.out.println("Please select your token:");
									tokenID = SaveOurPlanet.input.nextInt();

									tokenName = selectToken(tokenID - 1);

								} else {
									exists = false;
								}
							}

							token = new PlayerToken(tokenName);

						} while (players.size() > 0 && exists); // end inner inner do while loop (checking if token name
																// exists)

					} while (tokenID < MIN_TOKEN || tokenID > MAX_TOKEN); // end inner do
																			// while loop
					// (checking if user input is valid token value)

				} catch (InputMismatchException tokenMisMatch) {

					isException = true;

					// UC2 display error message use case
					System.out.println("");
					System.out.println("Invalid Input.");
					System.out.println("Please enter a number between " + MIN_TOKEN + " - " + MAX_TOKEN + " inclusive");

					SaveOurPlanet.input.nextLine();
				} // end try catch

			} while (isException == true); // end outer do while loop

			/*******************************************************************************************/

			/*
			 * Initialize player values and add to static 'players' array
			 */

			int playerPosition = 0;
			int carbonFootprint = player.getCarbonFootprint();
			// String playerToken = tokenName;

			// Initialize player class
			GamePlayer player = new GamePlayer(playerName, playerTurn, playerPosition, carbonFootprint, token);

			// add player object to players ArrayList
			players.add(addPlayer(player));

			// display Player message
			System.out.println(player.toString());
			System.out.println();

			// iterate to the next index for the ArrayList
			playerTurn++;

		} while (playerTurn <= numPlayers); // end outer do while

	} // end enterInfo method

	// UC3 make move use case
	public void makeMove(ArrayList<GamePlayer> players, ArrayList<Area> areas) {

		printGameStatsBanner();
		System.out.println("");
		printPlayerDetails(players);

		letsGoSound();

		// exit Game condition
		int exit = 0;
		int purchaseArea = 0;

		int countOwnedF1 = 0;
		int countOwnedF2 = 0;
		int countOwnedF3 = 0;
		int countOwnedF4 = 0;

		boolean loopFinished = false;

		ArrayList<Integer> fieldList;

		// index to determine player move
		int i = 0;

		do {

			boolean checkOwned = false;

			// UC4 display Info use case
			System.out.println("");
			printDivider();
			System.out.println(players.get(i).getPlayerName() + " it is your turn");

			// assign exitGame condition user input value from endGame() method
			// either the game continues or ends
			exit = endGame();

			// if end Game condition is met
			if (exit == END_GAME) {

				// UC4 display Info use case

				players.get(i).setCarbonFootprint(CARBON_FOOTPRINT_MAX_LIMIT);

				// check to see if a player has won or lost the game and end if conditions are
				// met
				if (continueGame(players.get(i).getCarbonFootprint(), players.get(i).getPlayerTurn() - 1) == END_GAME) {

					// printDivider();

					System.out.println("");
					System.out.println("                                    Thank you for playing Save Our Planet.");
					System.out.println("");
					if (roundCount == 1) {
						System.out.println(
								"                                              You played " + roundCount + " round.");
					} else {
						System.out.println(
								"                                              You played " + roundCount + " rounds.");
					}
					System.out.println("");

					printDivider();
					System.out.println("");

					printGameResultsBanner();
					System.out.println("");
					printPlayerDetails(players);
					System.out.println("");
					printDivider();
					resultsSound();

					exit = END_GAME;

					break;
				}

				printDivider();

				System.out.println("");
				System.out.println("                                    Thank you for playing Save Our Planet.");
				System.out.println("");
				if (roundCount == 1) {
					System.out.println(
							"                                              You played " + roundCount + " round.");
				} else {
					System.out.println(
							"                                              You played " + roundCount + " rounds.");
				}
				System.out.println("");

				printDivider();
				System.out.println("");

				printGameResultsBanner();
				System.out.println("");
				printPlayerDetails(players);
				System.out.println("");
				printDivider();
				resultsSound();

				break;

			} // end if (if player decides they wish to end the game)

			/*
			 * develop an area menu this will only appear if the current player whose turn
			 * it is owns all areas in at least 1 field, otherwise, the play will continue
			 * as normal
			 */
			do {

				fieldList = new ArrayList<Integer>();

				/*
				 * individual filed counts to check the amount of areas own by a player in each
				 * field against the expected amount of areas in each field
				 */
				countOwnedF1 = 0;
				countOwnedF2 = 0;
				countOwnedF3 = 0;
				countOwnedF4 = 0;

				// check to see if a players owns all areas in a field

				// loop 1
				for (int a = 1; a <= 2; a++) {

					PropertyArea propertyTemp = (PropertyArea) areas.get(a);

					if (players.get(i).getPlayerTurn() == propertyTemp.getIsOwned()) {

						countOwnedF1++;
						checkOwned = false;

					} else {
						checkOwned = true;
						break;
					}

				}

				// add to fieldList Array if a player owns all areas belonging to Field 1
				if (checkOwned == false && countOwnedF1 == 2) {

					fieldList.add(1);

					// comments for debugging
					// System.out.println("1." + players.get(i).getPlayerName() + " owns all the
					// areas in this field!");

				} else {

					// comments for debugging
					// System.out.println("1. player doesn't own the field");

				}

				// loop 2

				for (int b = 3; b <= 5; b++) {

					PropertyArea propertyTemp = (PropertyArea) areas.get(b);

					if (players.get(i).getPlayerTurn() == propertyTemp.getIsOwned()) {

						countOwnedF2++;

						checkOwned = false;

					} else {
						checkOwned = true;
						break;
					}
				}

				// add to fieldList Array if a player owns all areas belonging to Field 2
				if (checkOwned == false && countOwnedF2 == 3) {

					fieldList.add(2);

					// comments for debugging
					// System.out.println("2." + players.get(i).getPlayerName() + " owns all the
					// areas in this field!");

				} else {

					// comments for debugging
					// System.out.println("2. player doesn't own the field");
				}

				// loop 3

				for (int c = 7; c <= 9; c++) {

					PropertyArea propertyTemp = (PropertyArea) areas.get(c);

					if (players.get(i).getPlayerTurn() == propertyTemp.getIsOwned()) {

						countOwnedF3++;
						checkOwned = false;

					} else {
						checkOwned = true;
						break;
					}
				}

				// add to fieldList Array if a player owns all areas belonging to Field 3
				if (checkOwned == false && countOwnedF3 == 3) {

					fieldList.add(3);

					// comments for debugging
					// System.out.println("3." + players.get(i).getPlayerName() + " owns all the
					// areas in this field!");

				} else {

					// comments for debugging
					// System.out.println("3. player doesn't own the field");
				}

				for (int d = 10; d <= 11; d++) {

					PropertyArea propertyTemp = (PropertyArea) areas.get(d);

					if (players.get(i).getPlayerTurn() == propertyTemp.getIsOwned()) {

						countOwnedF4++;
						checkOwned = false;

					} else {
						checkOwned = true;
						break;
					}
				}

				// add to fieldList Array if a player owns all areas belonging to Field 4
				if (checkOwned == false && countOwnedF4 == 2) {

					fieldList.add(4);

					// comments for debugging
					// System.out.println("4." + players.get(i).getPlayerName() + " owns all the
					// areas in this field!");

				} else {

					// comments for debugging
					// System.out.println("4. player doesn't own the field");
				}

				if (fieldList.size() == 1) {
					System.out.println("");
					System.out.println("You currently own " + fieldList.size() + " Field.");
				} else if (fieldList.size() > 1) {
					System.out.println("");
					System.out.println("You currently own " + fieldList.size() + " Fields.");
				} else {

				}

				// develop field menu

				// ArrayList<Area> properties = new ArrayList<Area>();

				if (fieldList.size() > 0) {

					if (develop() == 1) {

						int pickField = developField(fieldList, areas, players.get(i).getPlayerTurn());

						// System.out.println(pickField);

						int areaDevelopments = developArea(pickField, areas, players.get(i).getPlayerTurn());

						developStructure(fieldList, areaDevelopments, areas, players.get(i).getPlayerTurn());

					} else {

					}

				}

				loopFinished = true;

			} while (loopFinished == false);

			/*
			 * if player decides to continue playing the game
			 */

			// UC4 display info message advising dice has been rolled
			System.out.println(players.get(i).getPlayerName() + " has rolled the Dice");

			rollDiceSound();

			int previousPosition = players.get(i).getPlayerPosition();

			// dice roll to determine what area player is to move to
			players.get(i).setPlayerPosition(rollDice());

			// UC4 display info message advising player what area they have landed on
			for (Area a : areas) {
				if (players.get(i).getPlayerPosition() == a.getIndex()) {
					System.out.println(players.get(i).getToken().getTokenName() + " has landed on " + a.getName());
				}
			}

			// check if a player passes go on each turn
			if (passGoGreen(areas, previousPosition, players.get(i).getPlayerPosition())) {
				
				GoGreenArea goGreenArea = (GoGreenArea) areas.get(0);

				players.get(i).setCarbonFootprint(collectGoGreen(areas, players.get(i).getCarbonFootprint()));

				// UC4 display info message advising player they have passed go and their carbon
				// footprint has been reduced
				System.out.println("");

				if (players.get(i).getPlayerPosition() == board.getAreas().get(i).getIndex()) {

					passGoGreenSound();

					System.out.println("Your carbon footprint has been reduced by " + goGreenArea.getValue() + "!");
					System.out.println("");
				} else {

					System.out.println(players.get(i).getToken().getTokenName() + ", you passed Go Green.");
					passGoGreenSound();
					System.out.println("");
					System.out.println("Your carbon footprint has been reduced by " + goGreenArea.getValue() + "!");
					System.out.println("");

				}
			}

			// check to see if a player has won or lost the game and end if conditions are
			// met
			if (continueGame(players.get(i).getCarbonFootprint(), players.get(i).getPlayerTurn() - 1) == END_GAME) {

				printDivider();

				System.out.println("");
				System.out.println("                                    Thank you for playing Save Our Planet.");
				System.out.println("");
				if (roundCount == 1) {
					System.out.println(
							"                                              You played " + roundCount + " round.");
				} else {
					System.out.println(
							"                                              You played " + roundCount + " rounds.");
				}
				System.out.println("");

				printDivider();
				System.out.println("");

				printGameResultsBanner();
				System.out.println("");
				printPlayerDetails(players);
				System.out.println("");
				printDivider();
				resultsSound();

				exit = END_GAME;

				break;
			}

			// print area details regaridng area
			getAreaDetails(board.getAreas(), players.get(i).getPlayerPosition());

			if (players.get(i).getPlayerPosition() == 0) {

				// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(0);

			} else if (players.get(i).getPlayerPosition() == 6) {

				// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(6);

			} else {

				PropertyArea propertyTemp = (PropertyArea) areas.get(players.get(i).getPlayerPosition());

				// if an area is not owned
				if (isOwned(board.getAreas(), players.get(i).getPlayerPosition()) == 0) {
					// System.out.println(players.get(i).getPlayerPosition());

					if (areas.get(players.get(i).getPlayerPosition()).getIndex() == 6) {

					} else if (areas.get(players.get(i).getPlayerPosition()).getIndex() == 0) {

					} else {

						propertyTemp = (PropertyArea) areas.get(players.get(i).getPlayerPosition());

						if (players.get(i).getCarbonFootprint()
								+ propertyTemp.getBuildPropertyCost() >= CARBON_FOOTPRINT_MAX_LIMIT) {

							System.out.println(
									"You can not develop on " + areas.get(players.get(i).getPlayerPosition()).getName()
											+ " as you would surpass the upper carbon limit and lose the game.");
						} else {

							System.out.println("This area is currently available to purchase.");

							System.out.println("would you like to purchase "
									+ areas.get(players.get(i).getPlayerPosition()).getName() + " for "
									+ propertyTemp.getAreaCost() + "?");

							// player decides whether they wish to purchase an area
							purchaseArea = purchaseAreaChoice();

							if (purchaseArea == 1) {

								propertyTemp = (PropertyArea) areas.get(players.get(i).getPlayerPosition());
								propertyTemp.setIsOwned(players.get(i).getPlayerTurn());

								// add area cost to player who purchases area
								players.get(i).setCarbonFootprint(
										players.get(i).getCarbonFootprint() + propertyTemp.getAreaCost());

								purchaseAreaSound();

								// UC4 informing the player of their purchase, how much their carbon footprint
								// has
								// increased by, and their total carbon footprint
								System.out.println("You have successfully purchased "
										+ areas.get(players.get(i).getPlayerPosition()).getName() + "!");
								System.out.println("Your carbon footprint has been increased by "
										+ propertyTemp.getAreaCost() + ".");
								System.out.println(
										"Your carbon footprint is " + players.get(i).getCarbonFootprint() + ".");

							} else {

								System.out.println("You have decided to NOT purchase this area.");
								System.out.println("This area is still available for a player to purchase.");
							}
						}
					}
					// if an area is already owned
				} else {

					propertyTemp = (PropertyArea) areas.get(players.get(i).getPlayerPosition());

					if (players.get(i).getPlayerTurn() == propertyTemp.getIsOwned()) {
						System.out.println("you have landed on your own area");

					} else {

						int owner = propertyTemp.getIsOwned();

						// UC4 informing the player who the area belongs to
						System.out.println("this area is currently owned by " + players.get(owner - 1).getPlayerName());
						System.out.println("");

						// UC4 informing the player how much their carbon footprint has been increased
						// by
						System.out.println(players.get(i).getPlayerName() + ", your carbon footprint has increased by "
								+ propertyTemp.getPolluteCost() + " for visiting " + propertyTemp.getName() + ".");

						// decrease the owners carbon footprint
						players.get(owner - 1).setCarbonFootprint(
								players.get(owner - 1).getCarbonFootprint() - propertyTemp.getPolluteCost());

						// increase the current players carbon footprint
						players.get(i).setCarbonFootprint(
								players.get(i).getCarbonFootprint() + propertyTemp.getPolluteCost());

						// check to see if a player has won or lost the game and end if conditions are
						// met
						if (continueGame(players.get(i).getCarbonFootprint() + propertyTemp.getPolluteCost(),
								players.get(i).getPlayerTurn() - 1) == END_GAME) {

							System.out.println("");
							System.out.println(
									"                                    Thank you for playing Save Our Planet.");
							System.out.println("");
							if (roundCount == 1) {
								System.out.println("                                              You played "
										+ roundCount + " round.");
							} else {
								System.out.println("                                              You played "
										+ roundCount + " rounds.");
							}
							System.out.println("");

							printDivider();
							System.out.println("");

							printGameResultsBanner();
							System.out.println("");
							printPlayerDetails(players);
							System.out.println("");
							printDivider();
							resultsSound();

							exit = END_GAME;

							break;

						} else if (continueGame(players.get(owner - 1).getCarbonFootprint(),
								players.get(owner - 1).getPlayerTurn() - 1) == END_GAME) {

							printDivider();

							System.out.println("");
							System.out.println(
									"                                    Thank you for playing Save Our Planet.");
							System.out.println("");
							if (roundCount == 1) {
								System.out.println("                                              You played "
										+ roundCount + " round.");
							} else {
								System.out.println("                                              You played "
										+ roundCount + " rounds.");
							}
							System.out.println("");

							printDivider();
							System.out.println("");

							printGameResultsBanner();
							System.out.println("");
							printPlayerDetails(players);
							System.out.println("");
							printDivider();
							resultsSound();

							exit = END_GAME;

							break;
						}

						else {

							printDivider();

							// UC4 informing the owner of the area who visited their area and how much their
							// carboon footprint has been decreased by
							System.out.println(players.get(owner - 1).getPlayerName() + ", "
									+ players.get(i).getPlayerName() + " has visited "
									+ areas.get(players.get(i).getPlayerPosition()).getName() + ". ");
							System.out.println("");
							System.out.println(
									"Your carbon footrpint has been reduced by " + propertyTemp.getPolluteCost() + ".");

						}
					}
				}

			}

			// iterator so next player can make a move
			i = changePlayer(players, i);

			printDivider();

			System.out.println("");
			printPlayerDetails(players);

		} while (exit != 2); // end do while

	} // end makeMove use case

	// check to see if the area is owned by a player
	public int isOwned(ArrayList<Area> area, int index) {

		PropertyArea propertyTemp = (PropertyArea) area.get(index);

		return propertyTemp.getIsOwned();

	} // end isOwned method

	// reduce players carbon footprint when they pass the Go Green area
	public int collectGoGreen(ArrayList<Area> areas, int goGreenValue) {
		
		GoGreenArea goGreenArea = (GoGreenArea) areas.get(0);

		return (goGreenValue - goGreenArea.getValue());

	} // end collectGoGreen method

	// check if a player has passed the go green square on each move
	public boolean passGoGreen(ArrayList<Area> areas, int previousPosition, int newPosition) {
		
		GoGreenArea goGreenArea = (GoGreenArea) areas.get(0);
		
		
		if (newPosition < previousPosition || newPosition == previousPosition
				|| newPosition == goGreenArea.getAREA()) {
			return true;
		}
		return false;

	} // end passGoGreen method

	// UC5 changePlayer use case
	public int changePlayer(ArrayList<GamePlayer> players, int index) {

		// iterator so next player can make a move
		index++;

		/*
		 * loop condition for player rounds once each player has taken a turn a new
		 * round starts this is a continuous loop until any exit conditions are met /
		 * triggered
		 */
		if (index == players.size()) {
			index = 0;

			// count the amount of rounds played
			roundCount++;
		} // end changePlayer method

		return index;
	} // end change player use case

	// UC14 end game use case
	public int endGame() {

		/*
		 * needs input mismatch validation so that if anything other than a variable
		 * type int is entered it can handle it without causing exception
		 */

		boolean isException = false;

		// initialize endGame value
		int continueGame = 0;

		do {

			try {

				isException = false;

				System.out.println();
				System.out.println("Do you wish to continue playing? \n1. Yes \n2. No");

				// player choice
				continueGame = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (continueGame < 1 || continueGame > 2) {
					// continue to check for a valid int until parameters are satisfied
					while (continueGame < 1 || continueGame > 2) {

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println("Do you wish to continue playing? \n1. Yes \n2. No");

						continueGame = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

			} catch (InputMismatchException endGameMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				System.out.println("Please enter either 1 or 2.");
				SaveOurPlanet.input.nextLine();
			}

		} while (isException == true);

		// output player choice as int value
		return continueGame;

	} // end endGame method

	// selecting a field the player wishes to develop
	public int developField(ArrayList<Integer> fieldNumber, ArrayList<Area> areas, int playerTurn) {

		boolean isException = false;

		// initialize develop value
		int develop = 0;
		int developSquare = 0;
		int d = 0;
		int e = 0;
		int i = 0;

		do {

			d = 0;

			try {

				isException = false;

				System.out.println();
				System.out.println("What Field do you wish to develop?");

				// output the fields owned in an indexed list
				for (d = 0; d < fieldNumber.size(); d++) {

					// initialize e to variable to avoid performing equations with iterator
					e = d;

					developSquare = fieldNumber.get(e);

					while (i < areas.size()) {

						if (areas.get(i).getIndex() == 0) {

							// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(i);
							i++;

						} else if (areas.get(i).getIndex() == 6) {

							// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(i);
							i++;

						} else {

							PropertyArea propertyTemp = (PropertyArea) areas.get(i);

							// index of the field list EQUALS the fieldIndex value (the value stored at that
							// index)
							if (propertyTemp.getField().getFieldIndex() == developSquare) {
								System.out.println(d + 1 + " " + propertyTemp.getField().getFieldName());
								break;
							}

							i++;

						}
					}

				}

				// reset iterators
				i = 0;
				d = 0;

				// player choice
				develop = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (develop < 1 || develop > fieldNumber.size()) {
					// continue to check for a valid int until parameters are satisfied
					while (develop < 1 || develop > fieldNumber.size()) {

						// reset iterators
						i = 0;
						d = 0;

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println();
						System.out.println("What Field do you wish to develop?");

						// output the fields owned in an indexed list
						for (d = 0; d < fieldNumber.size(); d++) {

							// initialize t to variable to avoid performing equations with iterator
							e = d;

							developSquare = fieldNumber.get(e);

							while (i < areas.size()) {

								if (areas.get(i).getIndex() == 0) {

									// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(i);
									i++;

								} else if (areas.get(i).getIndex() == 6) {

									// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(i);
									i++;

								} else {

									PropertyArea propertyTemp = (PropertyArea) areas.get(i);

									// index of the field list EQUALS the fieldIndex value (the value stored at that
									// index)
									if (propertyTemp.getField().getFieldIndex() == developSquare) {

										System.out.println(d + 1 + " " + propertyTemp.getField().getFieldName());
										break;
									}

									i++;

								}
							}
						}

						// player choice
						develop = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

				// taking user input and converting it to
				while (i < areas.size()) {
					developSquare = fieldNumber.get(develop - 1);
					i++;
					break;
				}

			} catch (InputMismatchException developAreaMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				SaveOurPlanet.input.nextLine();

				// reset iterators
				i = 0;
				d = 0;
			}

		} while (isException == true);

		// print statement for debugging
		// System.out.println(developSquare);

		// output field index of player choice as int value
		return developSquare;

	} // end developField method

	// selecting an area in the selected field the player wishes to develop
	public int developArea(int pickField, ArrayList<Area> areas, int playerTurn) {

		boolean isException = false;

		// initialize develop value
		int develop = 0;
		int developSquare = 0;
		int d = 0;
		int e = 0;
		int i = 0;
		int actualIndex = 0;
		int difference = 0;
		int count = 0;
		int totalCount = 0;

		do {

			count = 0;
			i = 0;
			d = 0;

			try {

				isException = false;

				System.out.println();
				System.out.println("What Area do you wish to develop?");

				// output the fields owned in an indexed list
				for (d = 0; d < areas.size(); d++) {

					// initialize e to variable to avoid performing equations with iterator
					e = d;

					developSquare = areas.get(e).getIndex();

					while (i < areas.size()) {

						if (areas.get(i).getIndex() == 0) {

							// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(i);
							i++;

						} else if (areas.get(i).getIndex() == 6) {

							// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(i);
							i++;

						} else {

							PropertyArea propertyTemp = (PropertyArea) areas.get(i);

							if (propertyTemp.getField().getFieldIndex() == pickField && propertyTemp.getIsOwned() == playerTurn) {

								System.out.println(e + 1 + " " + areas.get(i).getName());

								// print statement for debugging
								// System.out.println(areas.get(areas.get(i).getIndex()).getIndex());

								actualIndex = areas.get(areas.get(i).getIndex()).getIndex();
								difference = actualIndex - developSquare;
								count++;
								i++;

								break;
							} else {

							}

							i++;
						}
					}

				}

				totalCount = count;

				// print statement for debugging
				// System.out.println(totalCount);

				// reset iterators
				i = 0;
				d = 0;
				e = 0;
				count = 0;

				// player choice
				develop = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (develop < 1 || develop > totalCount) {

					// continue to check for a valid int until parameters are satisfied
					while (develop < 1 || develop > totalCount) {

						// reset iterators
						count = 0;
						i = 0;
						d = 0;
						e = 0;

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println();
						System.out.println("What Area do you wish to develop?");

						// output the fields owned in an indexed list
						for (d = 0; d < areas.size(); d++) {

							// initialize t to variable to avoid performing equations with iterator
							e = d;

							developSquare = areas.get(e).getIndex();

							while (i < areas.size()) {

								if (areas.get(i).getIndex() == 0) {

									// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(0);
									i++;

								} else if (areas.get(i).getIndex() == 6) {

									// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(6);
									i++;

								} else {

									PropertyArea propertyTemp = (PropertyArea) areas.get(i);

									if (propertyTemp.getField().getFieldIndex() == pickField
											&& propertyTemp.getIsOwned() == playerTurn) {

										System.out.println(e + 1 + " " + areas.get(i).getName());

										// print statement for debugging
										// System.out.println(areas.get(areas.get(i).getIndex()).getIndex());

										actualIndex = areas.get(areas.get(i).getIndex()).getIndex();
										difference = actualIndex - developSquare;

										count++;
										i++;

										break;
									} else {

									}

									i++;
								}
							}

						}

						totalCount = count;

						// print statement for debugging
						// System.out.println(totalCount);

						// player choice
						develop = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();

					}

					if (develop - 1 + difference == develop) {
						developSquare = develop;

						// print statement for debugging
						// System.out.println(developSquare + " 1");

						i++;

						break;
					} else {
						developSquare = areas.get((develop - 1) + difference).getIndex();

						// print statement for debugging
						// System.out.println(developSquare + " 2");

						i++;
						break;
					}

				}

				// taking user input and converting it to area index
				while (i < areas.size()) {

					// print statement for debugging
					// System.out.println(develop);
					// System.out.println(develop - 1 + difference);

					if (develop - 1 + difference == develop) {
						developSquare = develop;

						// print statement for debugging
						// System.out.println(developSquare + " 1");

						i++;

						break;
					} else {
						developSquare = areas.get((develop - 1) + difference).getIndex();

						// print statement for debugging
						// System.out.println(developSquare + " 2");

						i++;
						break;
					}

				}

				// print statement for debugging
				// System.out.println(developSquare + " outside");

			} catch (InputMismatchException developAreaMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				SaveOurPlanet.input.nextLine();

				// reset iterators
				i = 0;
				d = 0;
			}

		} while (isException == true);

		// print statement for debugging
		// System.out.println(developSquare);

		// print statement for debugging
		// System.out.println("You selected " + areas.get(developSquare).getName());

		// output field index of player choice as int value
		return developSquare;

	} // end developArea method

	// develop structure user selection method
	public int developStructure() {

		boolean isException = false;

		// initialize endGame value
		int develop = 0;

		do {

			try {

				isException = false;

				// System.out.println("");
				System.out.println("1. Yes \n2. No");

				// player choice
				develop = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (develop < 1 || develop > 2) {
					// continue to check for a valid int until parameters are satisfied
					while (develop < 1 || develop > 2) {

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println("1. Yes \n2. No");

						develop = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

			} catch (InputMismatchException developAreaMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				System.out.println("Please enter either 1 or 2.");
				SaveOurPlanet.input.nextLine();
			}

		} while (isException == true);

		// output player choice as int value
		return develop;

	} // end developStructure method

	// develop an area user selects whether to develop an area
	public int develop() {

		boolean isException = false;

		// initialize endGame value
		int develop = 0;

		do {

			try {

				isException = false;

				System.out.println();
				System.out.println("Would you like to create a development? \n1. Yes \n2. No");

				// player choice
				develop = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (develop < 1 || develop > 2) {
					// continue to check for a valid int until parameters are satisfied
					while (develop < 1 || develop > 2) {

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println("Would you like to create a development? \n1. Yes \n2. No");

						develop = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

			} catch (InputMismatchException developAreaMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				System.out.println("Please enter either 1 or 2.");
				SaveOurPlanet.input.nextLine();
			}

		} while (isException == true);

		// output player choice as int value
		return develop;

	} // end develop method

	// develop area user selection method
	public int developArea() {

		boolean isException = false;

		// initialize endGame value
		int develop = 0;

		do {

			try {

				isException = false;

				System.out.println();
				System.out.println("Do you wish to develop an area? \n1. Yes \n2. No");

				// player choice
				develop = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (develop < 1 || develop > 2) {
					// continue to check for a valid int until parameters are satisfied
					while (develop < 1 || develop > 2) {

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println("Do you wish to develop an area? \n1. Yes \n2. No");

						develop = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

			} catch (InputMismatchException developAreaMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				System.out.println("Please enter either 1 or 2.");
				SaveOurPlanet.input.nextLine();
			}

		} while (isException == true);

		// output player choice as int value
		return develop;

	} // end developArea method

	// develop a structure (minor/major development)
	public void developStructure(ArrayList<Integer> fieldList, int pickField, ArrayList<Area> areas, int playerTurn) {

		System.out.println("");

		if (pickField == 0) {

			// GoGreenArea goGreenTemp = (GoGreenArea) areas.get(0);

		} else if (pickField == 6) {

			// TakeABreakArea takeABreakTemp = (TakeABreakArea) areas.get(6);

		} else {

			PropertyArea propertyTemp = (PropertyArea) areas.get(pickField);

			if (players.get(playerTurn - 1).getCarbonFootprint()
					+ propertyTemp.getBuildPropertyCost() >= CARBON_FOOTPRINT_MAX_LIMIT) {
				System.out.println("You can not develop on " + propertyTemp.getName()
						+ " as you would surpass the upper carbon limit and lose the game.");

				if (fieldList.size() > 0) {

					if (develop() == 1) {

						pickField = developField(fieldList, areas, playerTurn);

						// System.out.println(pickField);

						int areaDevelopments = developArea(pickField, areas, playerTurn);

						developStructure(fieldList, areaDevelopments, areas, playerTurn);

					} else {

					}
				}

			} else {

				propertyTemp = (PropertyArea) areas.get(pickField);

				// this needs to be playerTurn-1 as player turn is index from 1, whereas, player
				// index in area starts at zero
				System.out.println(players.get(playerTurn - 1).getPlayerName() + ", you have selected "
						+ areas.get(pickField).getName() + " to develop.");

				if (propertyTemp.getDevelopmentCount() == 0) {

					System.out
							.println("There are currently no developments on " + areas.get(pickField).getName() + ".");
					System.out.println("Would you like to build a minor development for "
							+ propertyTemp.getBuildPropertyCost() + "?");

					if (developStructure() == 1) {

						// print statement for debugging
						// System.out.println("before");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						propertyTemp.setDevelopmentCount(1);
						propertyTemp.setPolluteCost(propertyTemp.getPolluteCost() * 3);

						/*
						 * value cant be hard coded here a variable will need created for property area
						 * for build property cost the cost can be work out by the risk level for each
						 * field (this is currently just for debugging
						 */
						players.get(playerTurn - 1).setCarbonFootprint(
								players.get(playerTurn - 1).getCarbonFootprint() + propertyTemp.getBuildPropertyCost());

						// print statement for debugging
						// System.out.println("after");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						System.out.println("");
						System.out.println("building development...");

						developmentSound();

						System.out.println("");
						System.out.println("You have successfully developed on " + propertyTemp.getName() + ".");
						System.out.println(
								"Your carbon footprint has been increased by " + propertyTemp.getBuildPropertyCost());
						System.out.println("");
					} else {

					}

				} else if (propertyTemp.getDevelopmentCount() == 1) {

					System.out.println("There are currently " + propertyTemp.getDevelopmentCount()
							+ " minor developments on " + areas.get(pickField).getName() + ".");
					System.out.println("Would you like to build a minor development for "
							+ propertyTemp.getBuildPropertyCost() + "?");

					if (developStructure() == 1) {

						// print statement for debugging
						// System.out.println("before");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						propertyTemp.setDevelopmentCount(2);
						propertyTemp.setPolluteCost(propertyTemp.getPolluteCost() * 3);

						players.get(playerTurn - 1).setCarbonFootprint(
								players.get(playerTurn - 1).getCarbonFootprint() + propertyTemp.getBuildPropertyCost());

						// print statement for debugging
						// System.out.println("after");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						System.out.println("");
						System.out.println("building development...");

						developmentSound();

						System.out.println("");
						System.out.println("You have successfully developed on " + propertyTemp.getName() + ".");
						System.out.println(
								"Your carbon footprint has been increased by " + propertyTemp.getBuildPropertyCost());
						System.out.println("");

					} else {

					}

				} else if (propertyTemp.getDevelopmentCount() == 2) {

					System.out.println("There are currently " + propertyTemp.getDevelopmentCount()
							+ " minor developments on " + areas.get(pickField).getName() + ".");
					System.out.println("Would you like to build a minor development for "
							+ propertyTemp.getBuildPropertyCost() + "?");

					if (developStructure() == 1) {

						// print statement for debugging
						// System.out.println("before");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						propertyTemp.setDevelopmentCount(3);
						propertyTemp.setPolluteCost(propertyTemp.getPolluteCost() * 3);

						players.get(playerTurn - 1).setCarbonFootprint(
								players.get(playerTurn - 1).getCarbonFootprint() + propertyTemp.getBuildPropertyCost());

						// print statement for debugging
						// System.out.println("after");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						System.out.println("");
						System.out.println("building development...");

						developmentSound();

						System.out.println("");
						System.out.println("You have successfully developed on " + propertyTemp.getName() + ".");
						System.out.println(
								"Your carbon footprint has been increased by " + propertyTemp.getBuildPropertyCost());
						System.out.println("");

					} else {

					}

				} else if (propertyTemp.getDevelopmentCount() == 3) {

					System.out.println("There are currently " + propertyTemp.getDevelopmentCount()
							+ " minor developments on " + areas.get(pickField).getName() + ".");
					System.out.println("You can no longer build any further minor developments.");
					System.out.println("Would you like to build a major development for "
							+ propertyTemp.getBuildPropertyCost() + "?");

					if (developStructure() == 1) {

						// print statement for debugging
						// System.out.println("before");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						propertyTemp.setDevelopmentCount(4);
						propertyTemp.setPolluteCost(propertyTemp.getPolluteCost() * 2);

						players.get(playerTurn - 1).setCarbonFootprint(
								players.get(playerTurn - 1).getCarbonFootprint() + propertyTemp.getBuildPropertyCost());

						// print statement for debugging
						// System.out.println("after");
						// System.out.println(areas.get(pickField).getPolluteCost());
						// System.out.println(areas.get(pickField).getDevelopmentCount());

						System.out.println("");
						System.out.println("building development...");

						developmentSound();

						System.out.println("");
						System.out.println("You have successfully developed on " + propertyTemp.getName() + ".");
						System.out.println(
								"Your carbon footprint has been increased by " + propertyTemp.getBuildPropertyCost());
						System.out.println("");

					} else {

						/*
						 * further additions need made to this else (is there an opportunity to use
						 * recursion here?) if a player gets to here and cannot develop because they
						 * have already developed the total amount of structures available, do we want
						 * their go to continue with their roll, or give them an opportunity (present
						 * them with the develop menu once more) to pick another area to develop?
						 */

					}

				} else {

					System.out.println("There is a major development on " + areas.get(pickField).getName() + ".");
					System.out.println("You can no longer develop on this area.");

					if (fieldList.size() > 0) {

						if (develop() == 1) {

							pickField = developField(fieldList, areas, playerTurn);

							// System.out.println(pickField);

							int areaDevelopments = developArea(pickField, areas, playerTurn);

							developStructure(fieldList, areaDevelopments, areas, playerTurn);

						} else {

						}
					}

				}
			}
		}

	} // end developStructure method

	// purchase area choice (player decides if they wish to purchase an area or not)
	public int purchaseAreaChoice() {

		/*
		 * needs input mismatch validation so that if anything other than a variable
		 * type int is entered it can handle it without causing exception
		 */

		boolean isException = false;

		// initialize endGame value
		int purchaseArea = 0;

		do {

			try {

				isException = false;

				System.out.println();
				System.out.println("1. Yes \n2. No");

				// player choice
				purchaseArea = SaveOurPlanet.input.nextInt();
				SaveOurPlanet.input.nextLine();

				// check if initial input is a valid int
				if (purchaseArea < 1 || purchaseArea > 2) {
					// continue to check for a valid int until parameters are satisfied
					while (purchaseArea < 1 || purchaseArea > 2) {

						// UC4 display Info use case
						System.out.println("");
						System.out.println("Invalid Selection");
						System.out.println("Please enter either 1 or 2.\n1. Yes \n2. No");

						purchaseArea = SaveOurPlanet.input.nextInt();
						SaveOurPlanet.input.nextLine();
					}
				}

			} catch (InputMismatchException purchaseAreaChoiceMismatch) {

				isException = true;

				System.out.println("");
				System.out.println("Invalid Input");
				System.out.println("Please enter either 1 or 2.");
				SaveOurPlanet.input.nextLine();
			}

		} while (isException == true);

		// output player choice as int value
		return purchaseArea;

	} // end purchaseAreaChoice method

	// check to see if MIN or MAX carbon footprint limit is met
	public int continueGame(int playerCarbonFootprint, int player) {
		if (playerCarbonFootprint == CARBON_FOOTPRINT_WIN_LIMIT || playerCarbonFootprint < CARBON_FOOTPRINT_WIN_LIMIT) {

			System.out.println("");
			printWinnerBanner();
			System.out.println("");
			System.out.println("                                            Congratulations");
			System.out
					.println("                                                " + players.get(player).getPlayerName());
			System.out.println("                                               You Win!");
			System.out.println("");
			winnerSound();
			return END_GAME;
		} else if (playerCarbonFootprint >= CARBON_FOOTPRINT_MAX_LIMIT) {

			printDivider();
			System.out.println("");
			printLoserBanner();
			System.out.println("");
			youLoseSound();
			printDivider();

			return END_GAME;
		}

		return 1;

	} // end continueGame method

	// UC6 roll dice use case
	// implements IDice interface
	@Override
	public Integer rollDice() {

		Random r = new Random();
		Integer roll1 = r.nextInt(6) + 1;
		Integer roll2 = r.nextInt(6) + 1;
		// UC4 display Info use case (main flow 1)
		System.out.println("");
		System.out.print("Dice 1 = " + roll1 + "     Dice 2 = " + roll2);
		System.out.println("");
		Integer movePlayer = roll1 + roll2;
		System.out.println("");

		if (movePlayer == 8 || movePlayer == 11) {
			System.out.println("you have rolled an " + movePlayer);
		} else {
			System.out.println("you have rolled a " + movePlayer);
		}
		System.out.println("");

		for (int i = 0; i < movePlayer; i++) {
			movePieceSound();
		}

		return movePlayer;

	} // end rollDice method

	// add player to ArrayList (supporting method)
	public GamePlayer addPlayer(GamePlayer player) {

		return player;

	} // end addPlayer method

	// select token switch statement
	public String selectToken(int token) {

		String tokenName = "";

		switch (token) {
		case 0:
			tokenName = player.getToken().getTOKEN1();
			break;
		case 1:
			tokenName = player.getToken().getTOKEN2();
			break;
		case 2:
			tokenName = player.getToken().getTOKEN3();
			break;
		case 3:
			tokenName = player.getToken().getTOKEN4();
			break;
		case 4:
			tokenName = player.getToken().getTOKEN5();
			break;
		case 5:
			tokenName = player.getToken().getTOKEN6();
			break;
		case 6:
			tokenName = player.getToken().getTOKEN7();
			break;
		case 7:
			tokenName = player.getToken().getTOKEN8();
			break;
		}

		return tokenName;
	} // end selectToken method

	/************************************************************************************************************************/
	/*
	 * print statements and sound effects
	 */

	// start banner for display purposes only
	@Override
	public void printStartGameBanner() {

		System.out.println("");
		System.out.println("");
		System.out.println(
				"                                 ___           ___                        ___                     \n"
						+ "                                /  /\\         /  /\\          ___         /  /\\                    \n"
						+ "                               /  /:/_       /  /::\\        /__/\\       /  /:/_                   \n"
						+ "                              /  /:/ /\\     /  /:/\\:\\       \\  \\:\\     /  /:/ /\\                  \n"
						+ "                             /  /:/ /::\\   /  /:/~/::\\       \\  \\:\\   /  /:/ /:/_                 \n"
						+ "                            /__/:/ /:/\\:\\ /__/:/ /:/\\:\\  ___  \\__\\:\\ /__/:/ /:/ /\\                \n"
						+ "                            \\  \\:\\/:/~/:/ \\  \\:\\/:/__\\/ /__/\\ |  |:| \\  \\:\\/:/ /:/                \n"
						+ "                             \\  \\::/ /:/   \\  \\::/      \\  \\:\\|  |:|  \\  \\::/ /:/                 \n"
						+ "                              \\__\\/ /:/     \\  \\:\\       \\  \\:\\__|:|   \\  \\:\\/:/                  \n"
						+ "                                /__/:/       \\  \\:\\       \\__\\::::/     \\  \\::/                   \n"
						+ "                                \\__\\/         \\__\\/           ~~~~       \\__\\/                    \n"
						+ "                                          ___           ___           ___                         \n"
						+ "                                         /  /\\         /__/\\         /  /\\                        \n"
						+ "                                        /  /::\\        \\  \\:\\       /  /::\\                       \n"
						+ "                                       /  /:/\\:\\        \\  \\:\\     /  /:/\\:\\                      \n"
						+ "                                      /  /:/  \\:\\   ___  \\  \\:\\   /  /:/~/:/                      \n"
						+ "                                     /__/:/ \\__\\:\\ /__/\\  \\__\\:\\ /__/:/ /:/___                    \n"
						+ "                                     \\  \\:\\ /  /:/ \\  \\:\\ /  /:/ \\  \\:\\/:::::/                    \n"
						+ "                                      \\  \\:\\  /:/   \\  \\:\\  /:/   \\  \\::/~~~~                     \n"
						+ "                                       \\  \\:\\/:/     \\  \\:\\/:/     \\  \\:\\                         \n"
						+ "                                        \\  \\::/       \\  \\::/       \\  \\:\\                        \n"
						+ "                                         \\__\\/         \\__\\/         \\__\\/                        \n"
						+ "                        ___                       ___           ___           ___                 \n"
						+ "                       /  /\\                     /  /\\         /__/\\         /  /\\          ___   \n"
						+ "                      /  /::\\                   /  /::\\        \\  \\:\\       /  /:/_        /  /\\  \n"
						+ "                     /  /:/\\:\\  ___     ___    /  /:/\\:\\        \\  \\:\\     /  /:/ /\\      /  /:/  \n"
						+ "                    /  /:/~/:/ /__/\\   /  /\\  /  /:/~/::\\   _____\\__\\:\\   /  /:/ /:/_    /  /:/   \n"
						+ "                   /__/:/ /:/  \\  \\:\\ /  /:/ /__/:/ /:/\\:\\ /__/::::::::\\ /__/:/ /:/ /\\  /  /::\\   \n"
						+ "                   \\  \\:\\/:/    \\  \\:\\  /:/  \\  \\:\\/:/__\\/ \\  \\:\\~~\\~~\\/ \\  \\:\\/:/ /:/ /__/:/\\:\\  \n"
						+ "                    \\  \\::/      \\  \\:\\/:/    \\  \\::/       \\  \\:\\  ~~~   \\  \\::/ /:/  \\__\\/  \\:\\ \n"
						+ "                     \\  \\:\\       \\  \\::/      \\  \\:\\        \\  \\:\\        \\  \\:\\/:/        \\  \\:\\\n"
						+ "                      \\  \\:\\       \\__\\/        \\  \\:\\        \\  \\:\\        \\  \\::/          \\__\\/\n"
						+ "                       \\__\\/                     \\__\\/         \\__\\/         \\__\\/                ");
		System.out.println("");
		System.out.println("");

	}

	// print area card details
	@Override
	public void getAreaDetails(ArrayList<Area> area, int areaPosition) {

		for (int i = 0; i < area.size(); i++) {

			if (areaPosition == 6) {

				System.out.println("");
				System.out.println("------------------------");
				System.out.println("|     " + area.get(areaPosition).getName() + "     |");
				System.out.println("|                      |");
				System.out.println("------------------------");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|      Just Relax!     |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("------------------------");

				break;

			} else if (areaPosition == 0) {
				
				GoGreenArea goGreenArea = (GoGreenArea) area.get(0);

				System.out.println("");
				System.out.println("------------------------");
				System.out.println("|       " + area.get(areaPosition).getName() + "       |");
				System.out.println("|                      |");
				System.out.println("------------------------");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("| You Passed Go Green! |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|        Carbon        |");
				System.out.println("|       Footprint      |");
				System.out.println("|       Reduction      |");
				System.out.println("|                      |");
				System.out.println("|          " + goGreenArea.getValue() + "         |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("|                      |");
				System.out.println("------------------------");

				break;

			} else if (area.get(i).getIndex() == areaPosition) {

				PropertyArea propertyTemp = (PropertyArea) area.get(i);

				System.out.println("");
				System.out.println("------------------------");

				if (propertyTemp.getField().getFieldName().length() == 2) {
					System.out.println("|          " + propertyTemp.getField().getFieldName() + "          |");
				} else if (propertyTemp.getField().getFieldName().length() == 3) {
					System.out.println("|          " + propertyTemp.getField().getFieldName() + "         |");
				} else if (propertyTemp.getField().getFieldName().length() == 4) {
					System.out.println("|         " + propertyTemp.getField().getFieldName() + "         |");
				} else if (propertyTemp.getField().getFieldName().length() == 5) {
					System.out.println("|         " + propertyTemp.getField().getFieldName() + "        |");
				} else if (propertyTemp.getField().getFieldName().length() == 6) {
					System.out.println("|        " + propertyTemp.getField().getFieldName() + "        |");
				} else if (propertyTemp.getField().getFieldName().length() == 7) {
					System.out.println("|        " + propertyTemp.getField().getFieldName() + "       |");
				} else if (propertyTemp.getField().getFieldName().length() == 8) {
					System.out.println("|       " + propertyTemp.getField().getFieldName() + "       |");
				} else if (propertyTemp.getField().getFieldName().length() == 9) {
					System.out.println("|       " + propertyTemp.getField().getFieldName() + "      |");
				} else if (propertyTemp.getField().getFieldName().length() == 10) {
					System.out.println("|      " + propertyTemp.getField().getFieldName() + "      |");
				} else if (propertyTemp.getField().getFieldName().length() == 11) {
					System.out.println("|      " + propertyTemp.getField().getFieldName() + "     |");
				} else if (propertyTemp.getField().getFieldName().length() == 12) {
					System.out.println("|     " + propertyTemp.getField().getFieldName() + "     |");
				} else if (propertyTemp.getField().getFieldName().length() == 13) {
					System.out.println("|     " + propertyTemp.getField().getFieldName() + "    |");
				} else if (propertyTemp.getField().getFieldName().length() == 14) {
					System.out.println("|    " + propertyTemp.getField().getFieldName() + "    |");
				} else if (propertyTemp.getField().getFieldName().length() == 15) {
					System.out.println("|    " + propertyTemp.getField().getFieldName() + "   |");
				} else {
					System.out.println("     " + propertyTemp.getField().getFieldName());
				}

				System.out.println("|                      |");
				System.out.println("------------------------");

				if (area.get(i).getName().length() == 2) {
					System.out.println("|          " + area.get(i).getName() + "          |");
				} else if (area.get(i).getName().length() == 3) {
					System.out.println("|          " + area.get(i).getName() + "         |");
				} else if (area.get(i).getName().length() == 4) {
					System.out.println("|         " + area.get(i).getName() + "         |");
				} else if (area.get(i).getName().length() == 5) {
					System.out.println("|         " + area.get(i).getName() + "        |");
				} else if (area.get(i).getName().length() == 6) {
					System.out.println("|        " + area.get(i).getName() + "        |");
				} else if (area.get(i).getName().length() == 7) {
					System.out.println("|        " + area.get(i).getName() + "       |");
				} else if (area.get(i).getName().length() == 8) {
					System.out.println("|       " + area.get(i).getName() + "       |");
				} else if (area.get(i).getName().length() == 9) {
					System.out.println("|       " + area.get(i).getName() + "      |");
				} else if (area.get(i).getName().length() == 10) {
					System.out.println("|      " + area.get(i).getName() + "      |");
				} else if (area.get(i).getName().length() == 11) {
					System.out.println("|      " + area.get(i).getName() + "     |");
				} else if (area.get(i).getName().length() == 12) {
					System.out.println("|     " + area.get(i).getName() + "     |");
				} else if (area.get(i).getName().length() == 13) {
					System.out.println("|     " + area.get(i).getName() + "    |");
				} else {
					System.out.println("     " + area.get(i).getName());
				}

				System.out.println("|                      |");
				System.out.println("------------------------");
				System.out.println("|         Cost         |");

				if (propertyTemp.getAreaCost() > 0 && propertyTemp.getAreaCost() < 100) {
					System.out.println("|         " + propertyTemp.getAreaCost() + "         |");
				} else if (propertyTemp.getAreaCost() > 99 && propertyTemp.getAreaCost() < 1000) {
					System.out.println("|         " + propertyTemp.getAreaCost() + "          |");
				} else {
					System.out.println("|         " + propertyTemp.getAreaCost() + "         |");
				}
				System.out.println("|                      |");
				System.out.println("------------------------");
				System.out.println("|     Pollute Cost     |");

				/*
				 * this will need amended to print the initial pay pollute cost for each field
				 * so that further pollute costs are accurate when printed, i.e. with 1 minor
				 * development mathematically the addition and subtraction from each player is
				 * working as expected we may need to consider adding the risk level as an
				 * attribute to each area?
				 */

				int developmentEquation = (propertyTemp.getPOLLUTE_COST() * propertyTemp.getField().getRiskLevel());

				if (developmentEquation > 0 && developmentEquation < 100) {
					System.out.println("|          " + developmentEquation + "          |");
				} else if (developmentEquation > 99 && developmentEquation < 1000) {
					System.out.println("|         " + developmentEquation + "          |");
				} else {
					System.out.println("|         " + developmentEquation + "         |");
				}

				System.out.println("|                      |");
				System.out.println("|         With:        |");
				System.out.println("|  1 Minor Development |");
				if ((developmentEquation * 3) > 9 && (developmentEquation * 3) < 100) {
					System.out.println("|          " + (developmentEquation * 3) + "          |");
				} else if ((developmentEquation * 3) > 99 && (developmentEquation * 3) < 1000) {
					System.out.println("|          " + (developmentEquation * 3) + "         |");
				} else {
					System.out.println("|        " + (developmentEquation * 3) + "          |");
				}
				System.out.println("|                      |");
				System.out.println("| 2 Minor Developments |");

				if ((developmentEquation * 3 * 3) > 99 && (developmentEquation * 3 * 3) < 1000) {

					System.out.println("|          " + (developmentEquation * 3 * 3) + "         |");

				} else if ((developmentEquation * 3 * 3) > 999 && (developmentEquation * 3 * 3) < 10000) {

					System.out.println("|         " + (developmentEquation * 3 * 3) + "         |");

				} else {

					System.out.println("|        " + (developmentEquation * 3 * 3) + "          |");

				}
				System.out.println("|                      |");
				System.out.println("| 3 Minor Developments |");
				if ((developmentEquation * 3 * 3 * 3) > 99 && (developmentEquation * 3 * 3 * 3) < 1000) {

					System.out.println("|          " + (developmentEquation * 3 * 3 * 3) + "         |");

				} else if ((developmentEquation * 3 * 3 * 3) > 999 && (developmentEquation * 3 * 3 * 3) < 10000) {

					System.out.println("|         " + (developmentEquation * 3 * 3 * 3) + "         |");

				} else {

					System.out.println("|        " + (developmentEquation * 3 * 3 * 3) + "          |");

				}

				System.out.println("|                      |");
				System.out.println("|  1 Major Development |");
				if ((developmentEquation * 3 * 3 * 3 * 2) > 99 && (developmentEquation * 3 * 3 * 3 * 2) < 1000) {

					System.out.println("|         " + (developmentEquation * 3 * 3 * 3 * 2) + "          |");
				} else if ((developmentEquation * 3 * 3 * 3 * 2) > 999
						&& (developmentEquation * 3 * 3 * 3 * 2) < 10000) {

					System.out.println("|         " + (developmentEquation * 3 * 3 * 3 * 2) + "         |");

				} else {

					System.out.println("|        " + (developmentEquation * 3 * 3 * 3 * 2) + "          |");

				}
				System.out.println("|                      |");
				System.out.println("------------------------");

			}
		}

		System.out.println();
	}

	// end game banner for display purposes only
	@Override
	public void printEndGameBanner() {

		System.out.println("");
		printDivider();
		System.out.println("");
		System.out.println("                                 ___           ___           ___           ___     \n"
				+ "                                /  /\\         /  /\\         /__/\\         /  /\\    \n"
				+ "                               /  /:/_       /  /::\\       |  |::\\       /  /:/_   \n"
				+ "                              /  /:/ /\\     /  /:/\\:\\      |  |:|:\\     /  /:/ /\\  \n"
				+ "                             /  /:/_/::\\   /  /:/~/::\\   __|__|:|\\:\\   /  /:/ /:/_ \n"
				+ "                            /__/:/__\\/\\:\\ /__/:/ /:/\\:\\ /__/::::| \\:\\ /__/:/ /:/ /\\\n"
				+ "                            \\  \\:\\ /~~/:/ \\  \\:\\/:/__\\/ \\  \\:\\~~\\__\\/ \\  \\:\\/:/ /:/\n"
				+ "                             \\  \\:\\  /:/   \\  \\::/       \\  \\:\\        \\  \\::/ /:/ \n"
				+ "                              \\  \\:\\/:/     \\  \\:\\        \\  \\:\\        \\  \\:\\/:/  \n"
				+ "                               \\  \\::/       \\  \\:\\        \\  \\:\\        \\  \\::/   \n"
				+ "                                \\__\\/         \\__\\/         \\__\\/         \\__\\/    \n"
				+ "                                 ___                        ___           ___      \n"
				+ "                                /  /\\          ___         /  /\\         /  /\\     \n"
				+ "                               /  /::\\        /__/\\       /  /:/_       /  /::\\    \n"
				+ "                              /  /:/\\:\\       \\  \\:\\     /  /:/ /\\     /  /:/\\:\\   \n"
				+ "                             /  /:/  \\:\\       \\  \\:\\   /  /:/ /:/_   /  /:/~/:/   \n"
				+ "                            /__/:/ \\__\\:\\  ___  \\__\\:\\ /__/:/ /:/ /\\ /__/:/ /:/___ \n"
				+ "                            \\  \\:\\ /  /:/ /__/\\ |  |:| \\  \\:\\/:/ /:/ \\  \\:\\/:::::/ \n"
				+ "                             \\  \\:\\  /:/  \\  \\:\\|  |:|  \\  \\::/ /:/   \\  \\::/~~~~  \n"
				+ "                              \\  \\:\\/:/    \\  \\:\\__|:|   \\  \\:\\/:/     \\  \\:\\      \n"
				+ "                               \\  \\::/      \\__\\::::/     \\  \\::/       \\  \\:\\     \n"
				+ "                                \\__\\/           ~~~~       \\__\\/         \\__\\/     ");
		System.out.println("");
		printDivider();
	}

	// stats game banner for display purposes only
	@Override
	public void printGameStatsBanner() {

		System.out.println(
				"                                 ___                       ___                       ___     \n"
						+ "                                /  /\\          ___        /  /\\          ___        /  /\\    \n"
						+ "                               /  /:/_        /  /\\      /  /::\\        /  /\\      /  /:/_   \n"
						+ "                              /  /:/ /\\      /  /:/     /  /:/\\:\\      /  /:/     /  /:/ /\\  \n"
						+ "                             /  /:/ /::\\    /  /:/     /  /:/~/::\\    /  /:/     /  /:/ /::\\ \n"
						+ "                            /__/:/ /:/\\:\\  /  /::\\    /__/:/ /:/\\:\\  /  /::\\    /__/:/ /:/\\:\\\n"
						+ "                            \\  \\:\\/:/~/:/ /__/:/\\:\\   \\  \\:\\/:/__\\/ /__/:/\\:\\   \\  \\:\\/:/~/:/\n"
						+ "                             \\  \\::/ /:/  \\__\\/  \\:\\   \\  \\::/      \\__\\/  \\:\\   \\  \\::/ /:/ \n"
						+ "                              \\__\\/ /:/        \\  \\:\\   \\  \\:\\           \\  \\:\\   \\__\\/ /:/  \n"
						+ "                                /__/:/          \\__\\/    \\  \\:\\           \\__\\/     /__/:/   \n"
						+ "                                \\__\\/                     \\__\\/                     \\__\\/    ");
		System.out.println("");
	}

	// winner game banner for display purposes only
	@Override
	public void printWinnerBanner() {

		System.out
				.println("               ___                       ___           ___           ___           ___     \n"
						+ "              /__/\\        ___          /__/\\         /__/\\         /  /\\         /  /\\    \n"
						+ "             _\\_ \\:\\      /  /\\         \\  \\:\\        \\  \\:\\       /  /:/_       /  /::\\   \n"
						+ "            /__/\\ \\:\\    /  /:/          \\  \\:\\        \\  \\:\\     /  /:/ /\\     /  /:/\\:\\  \n"
						+ "           _\\_ \\:\\ \\:\\  /__/::\\      _____\\__\\:\\   _____\\__\\:\\   /  /:/ /:/_   /  /:/~/:/  \n"
						+ "          /__/\\ \\:\\ \\:\\ \\__\\/\\:\\__  /__/::::::::\\ /__/::::::::\\ /__/:/ /:/ /\\ /__/:/ /:/___\n"
						+ "          \\  \\:\\ \\:\\/:/    \\  \\:\\/\\ \\  \\:\\~~\\~~\\/ \\  \\:\\~~\\~~\\/ \\  \\:\\/:/ /:/ \\  \\:\\/:::::/\n"
						+ "           \\  \\:\\ \\::/      \\__\\::/  \\  \\:\\  ~~~   \\  \\:\\  ~~~   \\  \\::/ /:/   \\  \\::/~~~~ \n"
						+ "            \\  \\:\\/:/       /__/:/    \\  \\:\\        \\  \\:\\        \\  \\:\\/:/     \\  \\:\\     \n"
						+ "             \\  \\::/        \\__\\/      \\  \\:\\        \\  \\:\\        \\  \\::/       \\  \\:\\    \n"
						+ "              \\__\\/                     \\__\\/         \\__\\/         \\__\\/         \\__\\/    ");
	}

	// results game banner for display purposes only
	@Override
	public void printGameResultsBanner() {

		System.out.println(
				"               ___           ___           ___           ___                                     ___     \n"
						+ "              /  /\\         /  /\\         /  /\\         /__/\\                        ___        /  /\\    \n"
						+ "             /  /::\\       /  /:/_       /  /:/_        \\  \\:\\                      /  /\\      /  /:/_   \n"
						+ "            /  /:/\\:\\     /  /:/ /\\     /  /:/ /\\        \\  \\:\\    ___     ___     /  /:/     /  /:/ /\\  \n"
						+ "           /  /:/~/:/    /  /:/ /:/_   /  /:/ /::\\   ___  \\  \\:\\  /__/\\   /  /\\   /  /:/     /  /:/ /::\\ \n"
						+ "          /__/:/ /:/___ /__/:/ /:/ /\\ /__/:/ /:/\\:\\ /__/\\  \\__\\:\\ \\  \\:\\ /  /:/  /  /::\\    /__/:/ /:/\\:\\\n"
						+ "          \\  \\:\\/:::::/ \\  \\:\\/:/ /:/ \\  \\:\\/:/~/:/ \\  \\:\\ /  /:/  \\  \\:\\  /:/  /__/:/\\:\\   \\  \\:\\/:/~/:/\n"
						+ "           \\  \\::/~~~~   \\  \\::/ /:/   \\  \\::/ /:/   \\  \\:\\  /:/    \\  \\:\\/:/   \\__\\/  \\:\\   \\  \\::/ /:/ \n"
						+ "            \\  \\:\\        \\  \\:\\/:/     \\__\\/ /:/     \\  \\:\\/:/      \\  \\::/         \\  \\:\\   \\__\\/ /:/  \n"
						+ "             \\  \\:\\        \\  \\::/        /__/:/       \\  \\::/        \\__\\/           \\__\\/     /__/:/   \n"
						+ "              \\__\\/         \\__\\/         \\__\\/         \\__\\/                                   \\__\\/    ");

	}

	// print loser banner for display purposes only
	@Override
	public void printLoserBanner() {

		System.out.println(
				"                                               ___           ___           ___           ___     \n"
						+ "                                              /  /\\         /  /\\         /  /\\         /  /\\    \n"
						+ "                                             /  /::\\       /  /:/_       /  /:/_       /  /::\\   \n"
						+ "                             ___     ___    /  /:/\\:\\     /  /:/ /\\     /  /:/ /\\     /  /:/\\:\\  \n"
						+ "                            /__/\\   /  /\\  /  /:/  \\:\\   /  /:/ /::\\   /  /:/ /:/_   /  /:/~/:/  \n"
						+ "                            \\  \\:\\ /  /:/ /__/:/ \\__\\:\\ /__/:/ /:/\\:\\ /__/:/ /:/ /\\ /__/:/ /:/___\n"
						+ "                             \\  \\:\\  /:/  \\  \\:\\ /  /:/ \\  \\:\\/:/~/:/ \\  \\:\\/:/ /:/ \\  \\:\\/:::::/\n"
						+ "                              \\  \\:\\/:/    \\  \\:\\  /:/   \\  \\::/ /:/   \\  \\::/ /:/   \\  \\::/~~~~ \n"
						+ "                               \\  \\::/      \\  \\:\\/:/     \\__\\/ /:/     \\  \\:\\/:/     \\  \\:\\     \n"
						+ "                                \\__\\/        \\  \\::/        /__/:/       \\  \\::/       \\  \\:\\    \n"
						+ "                                              \\__\\/         \\__\\/         \\__\\/         \\__\\/    ");
	}

	// divider line for display purposes only
	public void printDivider() {
		System.out.println(
				"----------------------------------------------------------------------------------------------------------------");
	}

	// roll Dice sound effect
	@Override
	public void rollDiceSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/diceroll.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// move piece sound effect
	@Override
	public void letsGoSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/letsgo.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// move piece sound effect
	@Override
	public void movePieceSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/movepiece.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// move piece sound effect
	@Override
	public void welcomeSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/welcome.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// results sound effect
	@Override
	public void resultsSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/resultsfanfare.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// winner sound effect
	@Override
	public void winnerSound() {

		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/winner.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	@Override
	public void developmentSound() {
		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/develop.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// you lose sound effect
	@Override
	public void youLoseSound() {
		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/youlose.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// purchase area sound effect
	@Override
	public void purchaseAreaSound() {
		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/purchasearea.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}

	// pass go green sound effect
	@Override
	public void passGoGreenSound() {
		try {
			FileInputStream fileInputStream = new FileInputStream("sounds/passgogreen.mp3");
			Player musicplayer = new Player(fileInputStream);
			musicplayer.play();
		} catch (FileNotFoundException | JavaLayerException e) {

			e.printStackTrace();
		}
	}
}// end class
