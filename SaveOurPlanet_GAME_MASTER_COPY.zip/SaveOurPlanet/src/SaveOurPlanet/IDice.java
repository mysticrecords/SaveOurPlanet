package SaveOurPlanet;

public interface IDice {
	
	//UC6 roll Dice use case
	public Integer rollDice();

}
