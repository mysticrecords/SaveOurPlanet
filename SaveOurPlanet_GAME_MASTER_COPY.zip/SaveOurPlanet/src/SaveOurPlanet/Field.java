package SaveOurPlanet;

public class Field {
	private String fieldName;
	private int fieldIndex;
	private int riskLevel;

	public Field(String fieldName, int fieldIndex, int riskLevel) {
		this.fieldName = fieldName;
		this.fieldIndex = fieldIndex;
		this.riskLevel = riskLevel;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldName() {
		return this.fieldName;
	}

	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}

	public int getFieldIndex() {
		return this.fieldIndex;
	}

	public void setRiskLevel(int riskLevel) {
		this.riskLevel = riskLevel;
	}

	public int getRiskLevel() {
		return this.riskLevel;
	}
}
