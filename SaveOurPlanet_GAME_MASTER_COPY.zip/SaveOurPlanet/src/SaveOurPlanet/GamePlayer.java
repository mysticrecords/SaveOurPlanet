package SaveOurPlanet;

import java.util.ArrayList;

public class GamePlayer {

	private final int TOKEN_LIMIT = 8;

	private ArrayList<PlayerToken> tokens = new ArrayList<PlayerToken>();

	private String playerName;
	private int playerTurn;
	private int playerPosition;
	private int carbonFootprint;
	private PlayerToken token;

	public GamePlayer() {

		for (int i = 0; i < TOKEN_LIMIT; i++) {

			if (i == 0) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 1) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 2) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 3) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 4) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 5) {
				tokens.add(token = new PlayerToken(i));
			} else if (i == 6) {
				tokens.add(token = new PlayerToken(i));
			} else {
				tokens.add(token = new PlayerToken(i));
			}
		}

	}

	public GamePlayer(String playerName, int playerTurn, int playerPosition, int carbonFootprint, PlayerToken token) {
		this.playerName = playerName;
		this.playerTurn = playerTurn;
		this.playerPosition = playerPosition;
		this.carbonFootprint = 4500;
		this.token = token;
	}

	/**
	 * @return the token
	 */
	public PlayerToken getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(PlayerToken token) {
		this.token = token;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getPlayerTurn() {
		return playerTurn;
	}

	public void setPlayerTurn(int playerTurn) {
		this.playerTurn = playerTurn;
	}

	public int getPlayerPosition() {
		return playerPosition;
	}

	/**
	 * validation for player roll (if a player roll takes them to or past the 'go
	 * green' area count the player roll -12 to determine right area to land on
	 * 
	 * @param playerPosition
	 */
	public void setPlayerPosition(int playerPosition) {
		this.playerPosition += playerPosition;
		if (this.playerPosition > 11) {
			this.playerPosition = this.playerPosition - 12;
		}
	}

	/**
	 * @return the carbonFootprint
	 */
	public int getCarbonFootprint() {
		return carbonFootprint;
	}

	/**
	 * @param carbonFootprint the carbonFootprint to set
	 */
	public void setCarbonFootprint(int carbonFootprint) {
		this.carbonFootprint = carbonFootprint;
	}

	public ArrayList<PlayerToken> getTokens() {
		return tokens;
	}

	// UC4 display info for enterInfo use case (when setting up the game)
	@Override
	public String toString() {

		String ordinal = "";
		if (playerTurn == 1) {
			ordinal = "st";
		}
		if (playerTurn == 2) {
			ordinal = "nd";
		}
		if (playerTurn == 3) {
			ordinal = "rd";
		}
		if (playerTurn == 4) {
			ordinal = "th";
		}

		return String.format("%s",
				"\n----------------------------------------------------------------------------------------------------------------"
						+ "\nWelcome " + playerName + "! \nYou have selected " + token.getTokenName()
						+ " as your token.  \nYou will move " + playerTurn + ordinal + "."
						+ "\n----------------------------------------------------------------------------------------------------------------");
	}

}
