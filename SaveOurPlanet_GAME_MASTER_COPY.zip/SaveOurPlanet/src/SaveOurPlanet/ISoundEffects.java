package SaveOurPlanet;

public interface ISoundEffects {
	
	public void rollDiceSound();
	
	public void movePieceSound();
	
	public void resultsSound();
	
	public void winnerSound();
	
	public void passGoGreenSound();
	
	public void purchaseAreaSound();
	
	public void youLoseSound();
	
	public void developmentSound();
	
	public void welcomeSound();
	
	public void letsGoSound();

}
