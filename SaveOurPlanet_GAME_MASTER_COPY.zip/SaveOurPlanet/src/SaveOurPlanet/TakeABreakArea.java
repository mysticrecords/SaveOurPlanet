package SaveOurPlanet;

public class TakeABreakArea extends Area {

	private final String TAKE_A_BREAK = "Take A Break";

	private final int AREA_SEVEN = 6;

	/**
	 * 
	 */
	public TakeABreakArea() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param name
	 * @param index
	 */
	public TakeABreakArea(int areaPosition) {

		if (areaPosition == 6) {
			super.setName(TAKE_A_BREAK);
			super.setIndex(AREA_SEVEN);

		}
	}

	/**
	 * @return the tAKE_A_BREAK
	 */
	public String getTAKE_A_BREAK() {
		return TAKE_A_BREAK;
	}

	/**
	 * @return the aREA_SEVEN
	 */
	public int getAREA_SEVEN() {
		return AREA_SEVEN;
	}

}
