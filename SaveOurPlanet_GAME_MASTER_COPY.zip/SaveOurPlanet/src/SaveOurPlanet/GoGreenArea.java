package SaveOurPlanet;

public class GoGreenArea extends Area {

	private final String GO_GREEN = "Go Green";

	private final int AREA_ONE = 0;

	private int value;

	/**
	 * 
	 */
	public GoGreenArea() {
		super();
		
	}

	/**
	 * @param name
	 * @param index
	 */
	public GoGreenArea(int areaPosition) {

		if (areaPosition == 0) {
			super.setName(GO_GREEN);
			super.setIndex(AREA_ONE);
			this.setValue(600);

		}
	}

	/**
	 * @return the gO_GREEN
	 */
	public String getGO_GREEN() {
		return GO_GREEN;
	}

	/**
	 * @return the aREA_ONE
	 */
	
	public int getAREA() {
		return AREA_ONE;
	}

	/**
	 * @return the value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(int value) {
		this.value = value;
	}

}
