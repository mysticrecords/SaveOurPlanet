/**
 * 
 */
package SaveOurPlanet;

/**
 * @author mattwalsh
 *
 */
public class PlayerToken {

	private final String TOKEN1 = "Boat";
	private final String TOKEN2 = "Car";
	private final String TOKEN3 = "Bicycle";
	private final String TOKEN4 = "Bus";
	private final String TOKEN5 = "Plane";
	private final String TOKEN6 = "Train";
	private final String TOKEN7 = "Helicopter";
	private final String TOKEN8 = "Motorcycle";

	private String tokenName;

	public PlayerToken() {

	}

	public PlayerToken(String tokenName) {
		this.tokenName = tokenName;
	}

	public PlayerToken(int tokenIndex) {
		if (tokenIndex == 0) {
			this.tokenName = TOKEN1;
		} else if (tokenIndex == 1) {
			this.tokenName = TOKEN2;
		} else if (tokenIndex == 2) {
			this.tokenName = TOKEN3;
		} else if (tokenIndex == 3) {
			this.tokenName = TOKEN4;
		} else if (tokenIndex == 4) {
			this.tokenName = TOKEN5;
		} else if (tokenIndex == 5) {
			this.tokenName = TOKEN6;
		} else if (tokenIndex == 6) {
			this.tokenName = TOKEN7;
		} else {
			this.tokenName = TOKEN8;
		}
	}

	/**
	 * @return the tokenName
	 */
	public String getTokenName() {
		return tokenName;
	}

	/**
	 * @param tokenName the tokenName to set
	 */
	public void setTokenName(String tokenName) {
		this.tokenName = tokenName;
	}

	/**
	 * @return the tOKEN1
	 */
	public String getTOKEN1() {
		return TOKEN1;
	}

	/**
	 * @return the tOKEN2
	 */
	public String getTOKEN2() {
		return TOKEN2;
	}

	/**
	 * @return the tOKEN3
	 */
	public String getTOKEN3() {
		return TOKEN3;
	}

	/**
	 * @return the tOKEN4
	 */
	public String getTOKEN4() {
		return TOKEN4;
	}

	/**
	 * @return the tOKEN5
	 */
	public String getTOKEN5() {
		return TOKEN5;
	}

	/**
	 * @return the tOKEN6
	 */
	public String getTOKEN6() {
		return TOKEN6;
	}

	/**
	 * @return the tOKEN7
	 */
	public String getTOKEN7() {
		return TOKEN7;
	}

	/**
	 * @return the tOKEN8
	 */
	public String getTOKEN8() {
		return TOKEN8;
	}

}
