package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TakeABreakAreaTest {
	
	TakeABreakArea takeabreakarea;
	

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	//negative test that position other than 6 is not take a break area 
	void testTakeABreakArea() {
		TakeABreakArea takeabreakarea = new TakeABreakArea(5);
		String expected = "Take A Break";
		String actual = takeabreakarea.getName();
		assertNotEquals(expected, actual);
	}

	@Test
	void testGetTAKE_A_BREAK() {
		TakeABreakArea takeabreakarea = new TakeABreakArea();
		String expected = "Take A Break";
		String actual = takeabreakarea.getTAKE_A_BREAK();
		assertEquals(expected, actual);
	}

	@Test
	void testGetAREA_SEVEN() {
		TakeABreakArea takeabreakarea = new TakeABreakArea();
		int expected = 6;
		int actual = takeabreakarea.getAREA_SEVEN();
		assertEquals(expected, actual);
	}


	@Test
	void testGetName() {
		TakeABreakArea takeabreakarea = new TakeABreakArea(6);
		String expected = "Take A Break";
		String actual = takeabreakarea.getName();
		assertEquals(expected, actual);

	}

	@Test
	void testGetIndex() {
		TakeABreakArea takeabreakarea = new TakeABreakArea();
		int expected = 0;
		int actual = takeabreakarea.getIndex();
		assertEquals(expected, actual);
		
		
	}

}
