package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class PropertyAreaTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

	}

	@Test
	void testPropertyAreaInt() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 3;
		int actual = propertyarea.getIndex();
		assertEquals(expected, actual);
	}

	@Test
	void testGetBuildPropertyCost() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 200;
		int actual = propertyarea.getBuildPropertyCost();
		assertEquals(expected, actual);
	}

	@Test
	void testGetAreaCost() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 200;
		int actual = propertyarea.getAreaCost();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPolluteCost() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 30;
		int actual = propertyarea.getPOLLUTE_COST();
		assertEquals(expected, actual);
	}

	@Test
	void testGetDevelopmentCount() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 0;
		int actual = propertyarea.getDevelopmentCount();
		assertEquals(expected, actual);
	}

	@Test
	void testGetIsOwned() {
		PropertyArea propertyarea = new PropertyArea(3);
		int expected = 0;
		int actual = propertyarea.getIsOwned();
		assertEquals(expected, actual);
	}

	@Test
	void testGetMAX_DEVELOPMENT_COUNT() {
		PropertyArea propertyarea = new PropertyArea();
		int expected = 4;
		int actual = propertyarea.getMAX_DEVELOPMENT_COUNT();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPOLLUTE_COST() {
		PropertyArea propertyarea = new PropertyArea();
		int expected = 30;
		int actual = propertyarea.getPOLLUTE_COST();
		assertEquals(expected, actual);
	}

	@Test
	void testGetName() {
		PropertyArea propertyarea = new PropertyArea(3);
		String expected = "UK";
		String actual = propertyarea.getName();
		assertEquals(expected, actual);
	}

	@Test
	void testSetName() {
		PropertyArea propertyarea = new PropertyArea();
		String expected = "HoHo";
		propertyarea.setName("HoHo");
		String actual = propertyarea.getName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetIndex() {
		PropertyArea propertyarea = new PropertyArea(2);
		int expected = 2;
		int actual = propertyarea.getIndex();
		assertEquals(expected, actual);
	}

	@Test
	void testSetIndex() {
		PropertyArea propertyarea = new PropertyArea();
		int expected = 5;
		propertyarea.setIndex(5);
		int actual = propertyarea.getIndex();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPolluteCost3() {
		PropertyArea propertyarea = new PropertyArea();
		int expected = 5;
		propertyarea.setPolluteCost(5);
		int actual = propertyarea.getPolluteCost();
		assertEquals(expected, actual);
	}

}
