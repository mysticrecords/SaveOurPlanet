package SaveOurPlanet;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class SaveOurPlanetTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@SuppressWarnings("static-access")
	@Test
	void testMain() {
		SaveOurPlanet saveourplanet = new SaveOurPlanet();
		System.out.println("main");
	    String[] args = null;
	    saveourplanet.main(args);

	}

}
