package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AreaTest {

	private static Area a;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
        a = new Area("France", 1) {
        };
	}

	/*@Test
	void testAreaStringInt() {
		fail("Not yet implemented");
	}*/

	@Test
	void testGetName() {
		String expected = "France";
		String actual = a.getName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetIndex() {
		int expected = 1;
		int actual = a.getIndex();
		assertEquals(expected, actual);
	}

}
