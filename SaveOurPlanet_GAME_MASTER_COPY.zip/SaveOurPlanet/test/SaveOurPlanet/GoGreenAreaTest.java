package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GoGreenAreaTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
//		GoGreenArea gogreenarea = new GoGreenArea();
	}

	@Test
	void testGetAREA() {
		GoGreenArea gogreenarea = new GoGreenArea();
		int expected = 0;
		int actual = gogreenarea.getAREA();
		assertEquals(expected, actual);
	}

	@Test
	void testGoGreenAreaIntValue1() {
		GoGreenArea gogreenarea = new GoGreenArea(2);
		int expected = 600;
		int actual = gogreenarea.getValue();
		assertNotEquals(expected, actual);
	}
	
	@Test
	void testGoGreenAreaIntValue2() {
		GoGreenArea gogreenarea = new GoGreenArea(0);
		int expected = 600;
		int actual = gogreenarea.getValue();
		assertEquals(expected, actual);
	}

	@Test
	void testGetGO_GREEN() {
		GoGreenArea gogreenarea = new GoGreenArea(0);
		String expected = "Go Green";
		String actual = gogreenarea.getGO_GREEN();
		assertEquals(expected, actual);
	}
	

	@Test
	void testGetValue() {
		GoGreenArea gogreenarea = new GoGreenArea();
		int expected = 200;
		gogreenarea.setValue(200);
		int actual = gogreenarea.getValue();
		assertEquals(expected, actual);
	}

	@Test
	void testAreaString() {
		Area gogreenarea = new GoGreenArea(0);
		String expected = "Go Green";
		gogreenarea.getName();
		String actual = gogreenarea.getName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetName() {
		Area gogreenarea = new GoGreenArea(0);
		String expected = "Go Green";
		String actual = gogreenarea.getName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetIndex() {
		Area gogreenarea = new GoGreenArea(0);
		int expected = 0;
		int actual = gogreenarea.getIndex();
		assertEquals(expected, actual);
	}

}
