package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GameTest {
	
	static Game game;
	static Game game1;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		System.out.println("Initialise Game 1. John and Paul, Boat and Car");
		game = new Game();
		System.out.println("Initialise Game 2. John and Paul, Boat and Car");
		game1 = new Game();
	}

	@Test
	void testGameBoard() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game();
		Board expected = game.getBoard();
		assertNotNull(expected);		
	}
	
	@Test
	void testGamePlayer() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		GamePlayer actual = game.getPlayer();
		assertNotNull(actual);
		
	}

	@Test
	void testGetBoard() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		Board actual = game.getBoard();
		assertNotNull(actual);
	}

	@Test
	void testGetPlayer() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		GamePlayer actual = game.getPlayer();
		assertNotNull(actual);
	}

	@Test
	void testGetPlayers() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> list = game.getPlayers();
		assertNotNull(list);
	}

	@Test
	void testPrintAreas() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		game.printAreas(areas);
		assertNotNull(areas);
	}

	@Test
	void testPrintPlayerDetails() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game.getPlayers();
		game.printPlayerDetails(players);
		assertNotNull(players);
	}

	@Test
	void testEnterInfo() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game.getPlayers();
		game.enterInfo(players);
		assertNotNull(players);
	}
	
	@Test
	void testEnterInvalidNumberofPlayers() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game1.getPlayers();
		System.out.println("For this test please input 1 as the nunber of players: ");
		System.out.println("After doing this then create players as normal: ");
		game1.enterInfo(players);
		assertNotNull(players);
	}

	@Test
	void testEnterInvalidInputNumberofPlayers() {
		Game game2 = new Game();
		ArrayList<GamePlayer> players = game2.getPlayers();
		System.out.println("For this test please input A as the nunber of players: ");
		System.out.println("After doing this then create players as normal: ");
		game2.enterInfo(players);
		assertNotNull(players);
	}
	
	@Test
	void testEnterDuplicatePlayerName() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game1.getPlayers();
		System.out.println("For this test please input 2 as number of players, then input the same name for both: ");
		System.out.println("After doing this then create players as normal: ");
		game1.enterInfo(players);
		assertNotNull(players);
	}
	
	@Test
	void testEnterDuplicateToken() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		////Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game.getPlayers();
		System.out.println("For this test please input 2 as number of players, input 2 names but select same token for each: ");
		System.out.println("After doing this then create players as normal: ");
		game.enterInfo(players);
		assertNotNull(players);
	}
	
	@Test
	void testEnterInvalidToken() {
		Game game2 = new Game();
		ArrayList<GamePlayer> players = game2.getPlayers();
		System.out.println("For this test please input 2 as number of players, input 2 names but input 10 for token number: ");
		System.out.println("After doing this then create players as normal: ");
		game2.enterInfo(players);
		assertNotNull(players);
	}
	
	@Test
	void testEnterBadInputToken() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game1.getPlayers();
		System.out.println("For this test please input 2 as number of players, input 2 names but input A for token number: ");
		System.out.println("After doing this then create players as normal: ");
		game1.enterInfo(players);
		assertNotNull(players);
	}


	
	@Test
	void testMakeMove() {
		Board board = new Board();
		//PlayerToken playertoken = new PlayerToken();
		//TakeABreakArea takeabreakarea = new TakeABreakArea();
		//GamePlayer gameplayer1 = new GamePlayer("John",3,1,2000,playertoken);
		//GamePlayer gameplayer2 = new GamePlayer("Paul",2,2,3000,playertoken);
		//Game game = new Game(board, gameplayer1);
		ArrayList<GamePlayer> players = game.getPlayers();
		ArrayList<Area> areas = board.getAreas();
		/*areas.add(0, board.getArea());
		areas.add(1, board.getArea());
		areas.add(2, board.getArea());
		areas.add(3, board.getArea());
		areas.add(4, board.getArea());
		areas.add(5, board.getArea());
		areas.add(6, board.getArea());
		areas.add(7, board.getArea());
		areas.add(8, board.getArea());
		areas.add(9, board.getArea());
		areas.add(10, board.getArea());
		areas.add(11, board.getArea());*/
		// add player object to players ArrayList
		//players.add(gameplayer1);
		//players.add(gameplayer2);
		
		//game.makeMove(game.getPlayers(), board.getAreas());
		game.makeMove(players, areas);
		//System.out.println(gameplayer1.getPlayerPosition());
		//assertNotNull(areas);
		
	}

	@Test
	void testIsOwned() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		int expected = 0;
		int actual = game.isOwned(board.getAreas(), 2);
		assertEquals(expected, actual);
	}

	@Test
	void testCollectGoGreen() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		ArrayList<Area> area = board.getAreas();
		//Game game = new Game(board, gameplayer);
		int expected = -600;
		int actual = game.collectGoGreen(area, 0);
		assertEquals(expected, actual);
	}

	@Test
	void testPassGoGreen() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		ArrayList<Area> area = board.getAreas();
		//Game game = new Game(board, gameplayer);
		boolean expected = true;
		boolean actual = game.passGoGreen(area, 10, 2);
		assertEquals(expected, actual);
	}

	@Test
	void testChangePlayer() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		ArrayList<GamePlayer> players = game.getPlayers();
		int expected = 2;
		int actual = game.changePlayer(players, 1);
		assertEquals(expected, actual);
	}

	@Test
	void testEndGameNo() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		int expected = 1;
		System.out.println("Do not end game for this test");
		int actual = game.endGame();
		assertEquals(expected, actual);
	}
	
	@Test
	void testEndGameYes() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		int expected = 2;
		System.out.println("Do end game for this test");
		int actual = game.endGame();
		assertEquals(expected, actual);
	}

	@Test
	void testDevelopField() {
		Board board = new Board();
		GamePlayer gameplayer = new GamePlayer();
		//Game game = new Game(board, gameplayer);
		ArrayList<Integer> fieldNumber = new ArrayList<Integer>();
		fieldNumber.add(0);
		fieldNumber.add(1);
		fieldNumber.add(2);
		fieldNumber.add(3);
		fieldNumber.add(4);
		fieldNumber.add(5);
		fieldNumber.add(6);
		fieldNumber.add(7);
		fieldNumber.add(8);
		fieldNumber.add(9);
		fieldNumber.add(10);
		fieldNumber.add(11);
		int expected =  1; 
		System.out.println("Enter choice 2 for this test");
		int actual = game.developField(fieldNumber, board.getAreas() , 1);
		assertEquals(expected, actual);
	}


	@Test
	void testContinueGame() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		
		int expected = 1;
		int actual = game.continueGame(3, 0);
		assertEquals(expected, actual);
	}

	@Test
	void testRollDice() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		

		int roll = game.rollDice();
		assertTrue(2 <= roll && roll <= 12);
	}

	@Test
	void testAddPlayer() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken(2);
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		GamePlayer result = game.addPlayer(gameplayer);
		//System.out.println(result.toString());
		assertNotNull(gameplayer.getPlayerName());
	}

	@Test
	void testSelectToken0() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Boat";
		String actual = game.selectToken(0);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken1() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Car";
		String actual = game.selectToken(1);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken2() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Bicycle";
		String actual = game.selectToken(2);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken3() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Bus";
		String actual = game.selectToken(3);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken4() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Plane";
		String actual = game.selectToken(4);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken5() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Train";
		String actual = game.selectToken(5);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken6() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Helicopter";
		String actual = game.selectToken(6);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSelectToken7() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		String expected = "Motorcycle";
		String actual = game.selectToken(7);
		assertEquals(expected, actual);
	}
	

	@Test
	void testPrintStartGameBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printStartGameBanner();
	}

	@Test
	void testGetAreaDetails() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.getAreaDetails(board.getAreas(), 1);
	}
	
	@Test
	void testGetAreaDetails0() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.getAreaDetails(board.getAreas(), 0);
	}
	
	@Test
	void testGetAreaDetails6() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.getAreaDetails(board.getAreas(), 6);
	}

	@Test
	void testPrintEndGameBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printEndGameBanner();
	}

	@Test
	void testPrintGameStatsBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printGameStatsBanner();
	}

	@Test
	void testPrintWinnerBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printWinnerBanner();
	}

	@Test
	void testPrintGameResultsBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printGameResultsBanner();
	}

	@Test
	void testPrintLoserBanner() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printLoserBanner();
	}

	@Test
	void testPrintDivider() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.printDivider();
	}

	@Test
	void testRollDiceSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.rollDiceSound();
	}

	@Test
	void testLetsGoSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.letsGoSound();
	}

	@Test
	void testMovePieceSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.movePieceSound();
	}

	@Test
	void testWelcomeSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.welcomeSound();
	}

	@Test
	void testResultsSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.resultsSound();
	}

	@Test
	void testWinnerSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.winnerSound();
	}

	@Test
	void testDevelopmentSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.developmentSound();
	}

	@Test
	void testYouLoseSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.youLoseSound();
	}

	@Test
	void testPurchaseAreaSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.purchaseAreaSound();
	}

	@Test
	void testPassGoGreenSound() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		game.passGoGreenSound();
	}
	
	@Test
	void testDevelopAreaIntArrayListOfAreaInt() {
		//(int pickField, ArrayList<Area> areas, int playerTurn)
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		PropertyArea propertyTemp2 = (PropertyArea) areas.get(2);
		propertyTemp2.setIsOwned(1);
		PropertyArea propertyTemp3 = (PropertyArea) areas.get(3);
		propertyTemp3.setIsOwned(1);
		PropertyArea propertyTemp4 = (PropertyArea) areas.get(4);
		propertyTemp4.setIsOwned(1);
		PropertyArea propertyTemp5 = (PropertyArea) areas.get(5);
		propertyTemp5.setIsOwned(1);
		PropertyArea propertyTemp7 = (PropertyArea) areas.get(7);
		propertyTemp7.setIsOwned(1);
		PropertyArea propertyTemp8 = (PropertyArea) areas.get(8);
		propertyTemp8.setIsOwned(1);
		PropertyArea propertyTemp9 = (PropertyArea) areas.get(9);
		propertyTemp9.setIsOwned(1);
		PropertyArea propertyTemp10 = (PropertyArea) areas.get(10);
		propertyTemp10.setIsOwned(1);
		
		int expected = 1;
		System.out.println(propertyTemp1.getField().getFieldName());
		System.out.println(propertyTemp2.getField().getFieldName());
		System.out.println(propertyTemp3.getField().getFieldName());
		System.out.println(propertyTemp4.getField().getFieldName() + propertyTemp4.getIsOwned() + propertyTemp4.getIndex()+1);
		int actual = game.developArea(1, board.getAreas(), 1);
		assertEquals(expected, actual);
	}
	
	@Test
	void testDevelopAreaInvalidInput() {
		//(int pickField, ArrayList<Area> areas, int playerTurn)
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		PropertyArea propertyTemp2 = (PropertyArea) areas.get(2);
		propertyTemp2.setIsOwned(1);
		PropertyArea propertyTemp3 = (PropertyArea) areas.get(3);
		propertyTemp3.setIsOwned(1);
		PropertyArea propertyTemp4 = (PropertyArea) areas.get(4);
		propertyTemp4.setIsOwned(1);
		PropertyArea propertyTemp5 = (PropertyArea) areas.get(5);
		propertyTemp5.setIsOwned(1);
		PropertyArea propertyTemp7 = (PropertyArea) areas.get(7);
		propertyTemp7.setIsOwned(1);
		PropertyArea propertyTemp8 = (PropertyArea) areas.get(8);
		propertyTemp8.setIsOwned(1);
		PropertyArea propertyTemp9 = (PropertyArea) areas.get(9);
		propertyTemp9.setIsOwned(1);
		PropertyArea propertyTemp10 = (PropertyArea) areas.get(10);
		propertyTemp10.setIsOwned(1);
		
		int expected = 1;
		System.out.println(propertyTemp1.getField().getFieldName());
		System.out.println(propertyTemp2.getField().getFieldName());
		System.out.println(propertyTemp3.getField().getFieldName());
		System.out.println(propertyTemp4.getField().getFieldName() + propertyTemp4.getIsOwned() + propertyTemp4.getIndex()+1);
		int actual = game.developArea(1, board.getAreas(), 1);
		assertEquals(expected, actual);
	}
	
	@Test
	void testDevelopAreaInvalidInputSelection() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		PropertyArea propertyTemp2 = (PropertyArea) areas.get(2);
		propertyTemp2.setIsOwned(1);
		PropertyArea propertyTemp3 = (PropertyArea) areas.get(3);
		propertyTemp3.setIsOwned(1);
		PropertyArea propertyTemp4 = (PropertyArea) areas.get(4);
		propertyTemp4.setIsOwned(1);
		PropertyArea propertyTemp5 = (PropertyArea) areas.get(5);
		propertyTemp5.setIsOwned(1);
		PropertyArea propertyTemp7 = (PropertyArea) areas.get(7);
		propertyTemp7.setIsOwned(1);
		PropertyArea propertyTemp8 = (PropertyArea) areas.get(8);
		propertyTemp8.setIsOwned(1);
		PropertyArea propertyTemp9 = (PropertyArea) areas.get(9);
		propertyTemp9.setIsOwned(1);
		PropertyArea propertyTemp10 = (PropertyArea) areas.get(10);
		propertyTemp10.setIsOwned(1);
		
		int expected = 1;
		System.out.println(propertyTemp1.getField().getFieldName());
		System.out.println(propertyTemp2.getField().getFieldName());
		System.out.println(propertyTemp3.getField().getFieldName());
		System.out.println(propertyTemp4.getField().getFieldName() + propertyTemp4.getIsOwned() + propertyTemp4.getIndex()+1);
		int actual = game.developArea(1, board.getAreas(), 1);
		assertEquals(expected, actual);
	}
	
	@Test
	void testDevelopAreaMaxCarbon() {
		Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,10000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		PropertyArea propertyTemp2 = (PropertyArea) areas.get(2);
		propertyTemp2.setIsOwned(1);
		PropertyArea propertyTemp3 = (PropertyArea) areas.get(3);
		propertyTemp3.setIsOwned(1);
		PropertyArea propertyTemp4 = (PropertyArea) areas.get(4);
		propertyTemp4.setIsOwned(1);
		PropertyArea propertyTemp5 = (PropertyArea) areas.get(5);
		propertyTemp5.setIsOwned(1);
		PropertyArea propertyTemp7 = (PropertyArea) areas.get(7);
		propertyTemp7.setIsOwned(1);
		PropertyArea propertyTemp8 = (PropertyArea) areas.get(8);
		propertyTemp8.setIsOwned(1);
		PropertyArea propertyTemp9 = (PropertyArea) areas.get(9);
		propertyTemp9.setIsOwned(1);
		PropertyArea propertyTemp10 = (PropertyArea) areas.get(10);
		propertyTemp10.setIsOwned(1);
		
		int expected = 1;
		System.out.println(propertyTemp1.getField().getFieldName());
		System.out.println(propertyTemp2.getField().getFieldName());
		System.out.println(propertyTemp3.getField().getFieldName());
		System.out.println(propertyTemp4.getField().getFieldName() + propertyTemp4.getIsOwned() + propertyTemp4.getIndex()+1);
		int actual = game.developArea(1, board.getAreas(), 1);
		assertEquals(expected, actual);
	}
	
	

	@Test
	void testDevelopStructureYes() {
				Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,10000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		
		int expected = 1;
		int actual = game.developStructure();
		assertEquals(expected, actual);
	}
	
	@Test
	void testDevelopStructureNo() {
				Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,10000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		
		int expected = 2;
		int actual = game.developStructure();
		assertEquals(expected, actual);
	}
	
	@Test
	void testDevelopStructureInvalidSelection() {
				Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,10000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		
		int expected = 1;
		int actual = game.developStructure();
		assertEquals(expected, actual);
	}

	@Test
	void testDevelopStructureInvalidInput() {
				Board board = new Board();
		PlayerToken playertoken = new PlayerToken(0);
		GamePlayer gameplayer = new GamePlayer("John",1,1,10000,playertoken);
		//Game game = new Game(board, gameplayer);
		ArrayList<Area> areas = board.getAreas();
		PropertyArea propertyTemp1 = (PropertyArea) areas.get(1);
		propertyTemp1.setIsOwned(1);
		
		int expected = 1;
		int actual = game.developStructure();
		assertEquals(expected, actual);
	}

}
