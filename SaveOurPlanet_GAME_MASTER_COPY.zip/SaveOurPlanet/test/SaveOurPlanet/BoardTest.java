package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class BoardTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
//		Board board = new Board();
	}

	@Test
	void testGetArea() {
		Board board = new Board();
		Area actual = board.getArea();
		assertNotNull(actual);
		
	}
	
	@Test
	void testSetArea() {
		Board board = new Board();
		board.setArea(board.getArea());
		Area actual = board.getArea();
		assertNotNull(actual);
		
	}

	@Test
	void testGetAreas() {
		Board board = new Board();
		ArrayList<Area> list = board.getAreas();
		int expected = 12;
		int actual = list.size();
	    assertEquals(expected, actual);
	}
	
	@Test
	void testSetAreas() {
		Board board = new Board();
		board.setAreas(board.getAreas());
		ArrayList<Area> actual = board.getAreas();
		assertNotNull(actual);
		
	}

}
