package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class FieldTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void testField() {
		
		Field field = new Field ("Northern Europe", 1, 2);
		int expectedindex = 1;
		int actualindex = field.getFieldIndex();
		assertEquals(expectedindex, actualindex);
		int expectedrisk = 2;
		int actualrisk = field.getRiskLevel();
		assertEquals(expectedrisk, actualrisk);
		String expectedfield = "Northern Europe";
		String actualfield = field.getFieldName();
		assertEquals(expectedfield, actualfield);
	}

	@Test
	
	void testGetFieldName() {
		Field field = new Field("Northern Europe", 1, 2);
		field.setFieldName("Eastern Europe");
		String expected = "Eastern Europe";
		String actual = field.getFieldName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetFieldIndex() {
		Field field = new Field("Northern Europe", 1, 2);
		field.setFieldIndex(2);
		int expected = 2;
		int actual = field.getFieldIndex();
		assertEquals(expected, actual);
	}

	@Test
	void testGetRiskLevel() {
		Field field = new Field("Northern Europe", 1, 2);
		field.setRiskLevel(3);
		int expected = 3;
		int actual = field.getRiskLevel();
		assertEquals(expected, actual);
	}

}
