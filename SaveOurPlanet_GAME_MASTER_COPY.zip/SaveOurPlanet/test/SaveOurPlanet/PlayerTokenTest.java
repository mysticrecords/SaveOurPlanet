package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class PlayerTokenTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
//		PlayerToken playertoken = new PlayerToken();
	}

	@Test
	void testPlayerTokenString() {
		PlayerToken playertoken = new PlayerToken("Player1");
		String expected = "Player1";
		String actual = playertoken.getTokenName();
		assertEquals(expected, actual);
	}

	@Test
	void testPlayerTokenInt() {
		PlayerToken playertoken = new PlayerToken(3);
		String expected = "Bus";
		String actual = playertoken.getTokenName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTokenName() {
		PlayerToken playertoken = new PlayerToken(2);
		String expected = "Bicycle";
		String actual = playertoken.getTokenName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN1() {
		PlayerToken playertoken = new PlayerToken(0);
		String expected = "Boat";
		String actual = playertoken.getTOKEN1();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN2() {
		PlayerToken playertoken = new PlayerToken(1);
		String expected = "Car";
		String actual = playertoken.getTOKEN2();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN3() {
		PlayerToken playertoken = new PlayerToken(2);
		String expected = "Bicycle";
		String actual = playertoken.getTOKEN3();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN4() {
		PlayerToken playertoken = new PlayerToken(3);
		String expected = "Bus";
		String actual = playertoken.getTOKEN4();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN5() {
		PlayerToken playertoken = new PlayerToken(4);
		String expected = "Plane";
		String actual = playertoken.getTOKEN5();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN6() {
		PlayerToken playertoken = new PlayerToken(5);
		String expected = "Train";
		String actual = playertoken.getTOKEN6();
		assertEquals(expected, actual);;
	}

	@Test
	void testGetTOKEN7() {
		PlayerToken playertoken = new PlayerToken(6);
		String expected = "Helicopter";
		String actual = playertoken.getTOKEN7();
		assertEquals(expected, actual);
	}

	@Test
	void testGetTOKEN8() {
		PlayerToken playertoken = new PlayerToken(7);
		String expected = "Motorcycle";
		String actual = playertoken.getTOKEN8();
		assertEquals(expected, actual);
	}
	
	@Test
	void testSetTokenName() {
		PlayerToken playertoken = new PlayerToken();
		String expected = "AntosCar";
		playertoken.setTokenName("AntosCar");
		String actual = playertoken.getTokenName();
		assertEquals(expected, actual);
	}


}
