package SaveOurPlanet;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class GamePlayerTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
//		GamePlayer gameplayer = new GamePlayer();
	}

	@Test
	void testGamePlayerStringIntIntIntPlayerToken() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		String expected = "John";
		String actual = gameplayer.getPlayerName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetToken() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("John",1,1,2000,playertoken);
		PlayerToken expected = playertoken;
		gameplayer.setToken(playertoken);
		PlayerToken actual = gameplayer.getToken();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPlayerName() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",1,1,2000,playertoken);
		gameplayer.setPlayerName("Marty");
		String expected = "Marty";
		String actual = gameplayer.getPlayerName();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPlayerTurn() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,1,2000,playertoken);
		int expected = 2;
		int actual = gameplayer.getPlayerTurn();
		assertEquals(expected, actual);
	}
	
	@Test
	void testSetPlayerTurn() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,1,2000,playertoken);
		gameplayer.setPlayerTurn(4);
		int expected = 4;
		int actual = gameplayer.getPlayerTurn();
		assertEquals(expected, actual);
	}

	@Test
	void testGetPlayerPosition() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		int expected = 2;
		int actual = gameplayer.getPlayerPosition();
		assertEquals(expected, actual);
	}
	
	@Test
	void testSetPlayerPosition() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		gameplayer.setPlayerPosition(6);
		int expected = 8;
		int actual = gameplayer.getPlayerPosition();
		assertEquals(expected, actual);
	}
	
	@Test
	void testSetPlayerPosition15() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		gameplayer.setPlayerPosition(15);
		int expected = 5;
		int actual = gameplayer.getPlayerPosition();
		assertEquals(expected, actual);
	}

	@Test
	void testGetCarbonFootprint() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		int expected = 4500;
		int actual = gameplayer.getCarbonFootprint();
		assertEquals(expected, actual);
	}
	
	@Test
	void testSetCarbonFootprint() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		gameplayer.setCarbonFootprint(4000);
		int expected = 4000;
		int actual = gameplayer.getCarbonFootprint();
		assertEquals(expected, actual);
	}


	@Test
	void testGetTokens() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		ArrayList<PlayerToken> actual = gameplayer.getTokens();
		assertNotNull(actual);
	}
	
	@Test
	void testGetString1() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",1,2,2000,playertoken);
		String expected1 = "\n----------------------------------------------------------------------------------------------------------------"
						+ "\nWelcome " + gameplayer.getPlayerName() + "! \nYou have selected " + playertoken.getTokenName()
						+ " as your token.  \nYou will move " + gameplayer.getPlayerTurn() + "st" + "."
						+ "\n----------------------------------------------------------------------------------------------------------------";
		String actual = gameplayer.toString();
		assertEquals(expected1, actual);
	}
	
	@Test
	void testGetString2() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",2,2,2000,playertoken);
		String expected1 = "\n----------------------------------------------------------------------------------------------------------------"
						+ "\nWelcome " + gameplayer.getPlayerName() + "! \nYou have selected " + playertoken.getTokenName()
						+ " as your token.  \nYou will move " + gameplayer.getPlayerTurn() + "nd" + "."
						+ "\n----------------------------------------------------------------------------------------------------------------";
		String actual = gameplayer.toString();
		assertEquals(expected1, actual);
	}
	
	@Test
	void testGetString3() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",3,2,2000,playertoken);
		String expected1 = "\n----------------------------------------------------------------------------------------------------------------"
						+ "\nWelcome " + gameplayer.getPlayerName() + "! \nYou have selected " + playertoken.getTokenName()
						+ " as your token.  \nYou will move " + gameplayer.getPlayerTurn() + "rd" + "."
						+ "\n----------------------------------------------------------------------------------------------------------------";
		String actual = gameplayer.toString();
		assertEquals(expected1, actual);
	}
	
	@Test
	void testGetString4() {
		PlayerToken playertoken = new PlayerToken();
		GamePlayer gameplayer = new GamePlayer("Paul",4,2,2000,playertoken);
		String expected1 = "\n----------------------------------------------------------------------------------------------------------------"
						+ "\nWelcome " + gameplayer.getPlayerName() + "! \nYou have selected " + playertoken.getTokenName()
						+ " as your token.  \nYou will move " + gameplayer.getPlayerTurn() + "th" + "."
						+ "\n----------------------------------------------------------------------------------------------------------------";
		String actual = gameplayer.toString();
		assertEquals(expected1, actual);
	}

}
